const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const API=(location.protocol==='file:'||location.port==='3000')?'http://localhost:8000':'';   // 3000 = 'npm start' (frontend only), backend runs on 8000
const S={lang:'en',user:{name:'Friend',gender:'',age:'',contact:''},cats:new Set(),lesson:null,step:0,done:new Set(),rem:[],cur:'splash',mode:'email',stage:0,grammar:false,ev:[],follow:[],followNew:false,exam:null,busy:false,voice:true};
const TABS=['home','explore','reminders','progress','profile'];
const t=k=>(T[S.lang]||{})[k]||T.en[k]||k;
const li=()=>({en:0,hi:1,or:2,ur:3})[S.lang];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SPEECH={en:'en-IN',hi:'hi-IN',or:'or-IN',ur:'ur-PK'};

function go(id){
  S.cur=id;window.orb3d&&orb3d(id);if(id!=='lesson'&&id!=='ai')stopSpeech();
  $$('.screen').forEach(s=>s.classList.toggle('active',s.id===id));
  const i=TABS.indexOf(id);
  $('#nav').classList.toggle('show',i>-1);
  if(i>-1)$('#ind').style.transform=`translateX(${(S.lang==='ur'?-i:i)*100}%)`;
  ({home:()=>{home();robotStart()},plans,explore,lesson:()=>renderLesson(1),reminders,progress,profile,exam:examScreen,chat:chatOpen,ai:()=>{AI.view='hub';aiScreen()}})[id]?.();
}
function applyLang(){
  document.documentElement.lang=S.lang;document.documentElement.dir=S.lang==='ur'?'rtl':'ltr';
  document.body.className='l-'+S.lang;
  $$('[data-i]').forEach(e=>e.textContent=t(e.dataset.i));
  $$('[data-p]').forEach(e=>e.placeholder=t(e.dataset.p));
  $$('#catCards .opt').forEach(c=>c.firstChild.textContent=CATS[c.dataset.i][0]+' '+t(CATS[c.dataset.i][1]));
  $('#fContact').placeholder=t(S.mode);
  go(S.cur);
}

/* splash -> login */
setTimeout(()=>go('login'),2600);

/* login */
$$('#fGender button').forEach(b=>b.onclick=()=>{$$('#fGender button').forEach(x=>x.classList.remove('on'));b.classList.add('on');S.user.gender=b.dataset.g});
$$('#fMode button').forEach(b=>b.onclick=()=>{$$('#fMode button').forEach(x=>x.classList.remove('on'));b.classList.add('on');S.mode=b.dataset.m;$('#fContact').placeholder=t(S.mode);$('#fContact').type=S.mode==='email'?'email':'password';$('#fContact').value='';$('#eye').classList.toggle('hide',S.mode==='email')});
$('#eye').onclick=()=>{const f=$('#fContact');f.type=f.type==='password'?'tel':'password';$('#eye').textContent=f.type==='password'?'👁️':'🙈'};
function fail(m){const e=$('#err');e.textContent=m;e.classList.remove('shake');void e.offsetWidth;e.classList.add('shake')}
$('#otpBtn').onclick=()=>{
  const n=$('#fName').value.trim(),a=+$('#fAge').value,c=$('#fContact').value.trim();
  if(S.stage===0){
    if(n.length<2)return fail('Name?');if(!S.user.gender)return fail(t('gender')+'?');if(!(a>=5&&a<=100))return fail(t('age')+' 5-100');
    if(S.mode==='email'?!/^\S+@\S+\.\S+$/.test(c):!/^\d{10}$/.test(c))return fail(t(S.mode)+'?');
    Object.assign(S.user,{name:n,age:a,contact:c});fail('');DB.signup(S.user);
    $('#otpBtn').classList.add('load');
    setTimeout(()=>{$('#otpBtn').classList.remove('load');$('#fOtp').classList.remove('hide');S.stage=1;$('#otpBtn').textContent=t('cont')},1000);
  }else{
    if(!/^\d{4}$/.test($('#fOtp').value))return fail('OTP: 4');
    $('#otpBtn').classList.add('load');DB.verify(S.user.contact,$('#fOtp').value).then(r=>{$('#otpBtn').classList.remove('load');if(r==='bad')return fail('OTP: 1234 (demo)');loadLocal();go(r&&r.categories&&r.categories.length?'home':'lang')});
  }
};

/* language + categories */
LANGS.forEach((l,i)=>{const d=document.createElement('div');d.className='opt'+(l.c==='en'?' sel':'');d.style.setProperty('--i',i);d.innerHTML=`${l.n}`;
  d.onclick=()=>{$$('#langCards .opt').forEach(x=>x.classList.remove('sel'));void d.offsetWidth;d.classList.add('sel');S.lang=l.c;applyLang();DB.save({language:l.c})};$('#langCards').append(d)});
CATS.forEach((c,i)=>{const d=document.createElement('div');d.className='opt';d.dataset.i=i;d.style.setProperty('--i',i);d.append(c[0]+' ');
  d.onclick=()=>{d.classList.toggle('sel');S.cats.has(i)?S.cats.delete(i):S.cats.add(i)};$('#catCards').append(d)});

/* home + explore */
function lessonCard(L,i){const d=document.createElement('div');d.className='card item';d.style.animationDelay=i*.07+'s';
  d.innerHTML=`<span class="ic">${L.icon}</span><div><b>${L.title[li()]}</b></div><span class="tag ${L.off?'off':''}">${t(L.off?'offline':'online')}</span>`;d.onclick=()=>openLesson(L.id);return d}
function home(){
  $('#hello').textContent=`${t('hi')}, ${S.user.name}!`;
  const p=Math.round(S.done.size/LESSONS.length*100);$('#pct').textContent=p+'%';
  $('#ring').style.strokeDashoffset=239-239*p/100;
  const r=$('#recList');r.innerHTML='';LESSONS.forEach((L,i)=>r.append(lessonCard(L,i)));
  ensureExam();const dn=LESSONS.filter(l=>S.done.has(l.id)).length;
  $('#examCta').innerHTML=courseDone()?`🎓 <b>${t('examReady')}</b>`:`📝 <b>${t('examPlan')}</b> · ${t('examLeft').replace('{a}',dn).replace('{b}',LESSONS.length)}`;
}
function explore(){const r=$('#exList');r.innerHTML='';LESSONS.forEach((L,i)=>r.append(lessonCard(L,i)))}

/* lesson */
function openLesson(id){S.lesson=LESSONS.find(l=>l.id===id);S.step=S.lesson.mats?-1:0;go('lesson')}
function renderLesson(dir){
  const L=S.lesson;if(!L)return;const n=L.steps.length,b=$('#lessonBody');let h='';
  $('#lessonNav').style.display=S.step>=n?'none':'flex';
  $('#bNext').textContent=t(S.step===n-1?'finish':'next');
  if(S.step<0)h=`<div class="pic">${art(L.id,-1,L.icon)}</div><h2>${L.title[li()]}</h2><div class="vrow">${vbar()}</div><h3>${t('mats')}</h3>`+L.mats.map(m=>`<label class="chk"><input type="checkbox"><span>${m[0]} ${m[li()+1]||m[1]}</span></label>`).join('');
  else if(S.step>=n)h=`<div class="badge">🏅</div><h2 class="c">${t('complete')}</h2><div class="pic">${art('done',-1,'🎉')}</div><div id="fuBox"></div>${courseDone()?`<button class="btn" onclick="go('exam')">🎓 ${t('examGo')}</button>`:''}<button class="btn" onclick="remindFor()">⏰ ${t('setRem')}</button><button class="btn ghost" onclick="go('home')">${t('home')}</button>`;
  else{const s=L.steps[S.step];h=`<div class="bar"><b style="width:${(S.step+1)/n*100}%"></b></div><p class="sm">${t('stepOf').replace('{n}',S.step+1).replace('{m}',n)}</p><div class="pic">${art(L.id,S.step,s[0])}</div><p class="txt">${stepTxt(s)}</p><div class="vrow">${vbar()}</div>${s[5]?`<div class="tip">💡 <b>${t('tip')}:</b> ${t('tipText')}</div>`:''}`}
  b.className='';b.style.setProperty('--dx',dir*40+'px');void b.offsetWidth;b.className='slide';b.innerHTML=h;
  S.vt=S.step<0?sent(L.title[li()])+' '+sent(t('mats')+': '+L.mats.map(m=>m[li()+1]||m[1]).join(', ')):S.step>=n?sent(t('complete')):(()=>{const s=L.steps[S.step];return sent(t('stepSay').replace('{n}',S.step+1).replace('{m}',n))+' '+sent(stepTxt(s))+(s[5]?' '+sent(t('tip')+': '+t('tipText')):'')})();
  if(S.voice&&S.cur==='lesson')speakAuto(S.vt);
}
const vbar=()=>`<button class="fq" data-v="say">🔊 ${t('listen')}</button><button class="fq ${S.voice?'on':''}" data-v="auto">${S.voice?'🔔':'🔕'} ${t('auto')}</button>`;
$('#lessonBody').addEventListener('click',e=>{const v=e.target.closest('[data-v]');if(!v)return;
  if(v.dataset.v==='say')speakAuto(S.vt);else{S.voice=!S.voice;if(!S.voice)stopSpeech();else speakAuto(S.vt);$$('#lessonBody [data-v=auto]').forEach(x=>{x.classList.toggle('on',S.voice);x.textContent=(S.voice?'🔔':'🔕')+' '+t('auto')})}});
$('#bNext').onclick=()=>{S.step++;if(S.step>=S.lesson.steps.length){const L=S.lesson,first=!S.done.has(L.id);S.done.add(L.id);DB.done(L.id);if(first)logEv('lesson',L.id);persist();confetti();
  /* automatic extras: follow-up questions for this lesson, and the exam plan once the whole course is finished */
  if(courseDone())buildExam();
  autoFollow(L).then(qs=>{const b=$('#fuBox');if(b&&S.cur==='lesson'&&S.lesson===L)b.innerHTML=`<div class="card"><b>💬 ${t('followT')}</b><div>${chips(qs)}</div></div>`})}renderLesson(1)};
$('#bBack').onclick=()=>{if(S.step<=(S.lesson.mats?-1:0))return go('explore');S.step--;renderLesson(-1)};
function confetti(){window.orbBoost&&orbBoost();for(let i=0;i<50;i++){const c=document.createElement('i');c.className='cf';c.style.cssText=`left:${Math.random()*100}vw;background:hsl(${255+Math.random()*60},80%,${60+Math.random()*25}%);animation-delay:${Math.random()*.8}s`;document.body.append(c);setTimeout(()=>c.remove(),3500)}}
function remindFor(){go('reminders');$('#rAct').value=S.lesson.id}

/* reminders */
function reminders(){
  const sel=$('#rAct');if(!sel.options.length)LESSONS.forEach(L=>sel.add(new Option(L.title[0],L.id)));
  [...sel.options].forEach((o,i)=>o.textContent=LESSONS[i].title[li()]);
  const list=$('#rList');list.innerHTML='';
  S.rem.forEach((r,i)=>{const w=document.createElement('div');w.className='swipe';const L=LESSONS.find(l=>l.id===r.a)||{icon:'🎓',title:[t('examPlan'),t('examPlan'),t('examPlan')]};
    w.innerHTML=`<div class="card item"><span class="ic">${L.icon}</span><div><b>${L.title[li()]}</b><p class="sm">${r.d||'—'} ${r.t} · ${t(r.rep)}</p></div><span>${r.on?'🔔':'🔕'}</span></div>`;
    const c=w.firstChild;let x0=null,dx=0;
    c.onpointerdown=e=>{x0=e.clientX;c.setPointerCapture(e.pointerId)};
    c.onpointermove=e=>{if(x0===null)return;dx=e.clientX-x0;c.style.transform=`translateX(${dx}px)`};
    c.onpointerup=()=>{if(Math.abs(dx)>90){c.style.transform=`translateX(${dx<0?-500:500}px)`;c.style.opacity=0;setTimeout(()=>{DB.delRem(r.id);S.rem.splice(i,1);reminders()},250)}else{c.style.transform='';if(Math.abs(dx)<5)showPopup(L)}x0=null;dx=0};
    list.append(w)});
}
function showPopup(L){const p=$('#popup');p.textContent='🔔 '+t('popup').replace('{a}',L.title[li()]);p.classList.add('show');setTimeout(()=>p.classList.remove('show'),2800)}
$('#rSave').onclick=()=>{S.rem.push({id:Date.now().toString(36),a:$('#rAct').value,d:$('#rDate').value,t:$('#rTime').value,rep:$('#rRep').value,on:$('#rOn').checked});DB.addRem(S.rem[S.rem.length-1]);reminders();showPopup(LESSONS.find(l=>l.id===$('#rAct').value))};

/* progress + profile */
function progress(){
  const v=[3,5,2,6,4,7,Math.min(10,S.done.size*2+1)],c=$('#chart');c.innerHTML=v.map(x=>'<i></i>').join('');
  setTimeout(()=>$$('#chart i').forEach((e,i)=>e.style.height=v[i]*10+'%'),80);
  const bd=[['🌱',1],['🔥',2],['🏅',3],['👑',5]];$('#badges').innerHTML=bd.map(b=>`<span class="${S.done.size>=b[1]?'on':''}">${b[0]}</span>`).join('');
  $('#doneN').textContent=S.done.size;window.growthCard&&growthCard();
}
function profile(){
  $('#pName').textContent=S.user.name;$('#pInfo').textContent=[{m:'♂',f:'♀',o:'⚧'}[S.user.gender],S.user.age,/^\d{10}$/.test(S.user.contact)?'•'.repeat(8)+S.user.contact.slice(-2):S.user.contact].filter(Boolean).join(' · ');
  $('#pLang').value=S.lang;$('#pCats').textContent=[...S.cats].map(i=>CATS[i][0]+' '+t(CATS[i][1])).join('  ')||'—';
}
$('#pLang').onchange=e=>{S.lang=e.target.value;applyLang();DB.save({language:S.lang})};

/* Auralis chatbot: steps + follow-up questions + "what you learned"; text, voice, image/video, grammar */
function bubble(cls,html){const d=document.createElement('div');d.className='m '+cls;d.innerHTML=html;const m=$('#msgs');m.append(d);m.scrollTop=m.scrollHeight;return d}   // (scrollIntoView used to shove the whole app up)
/* ---- Voice engine: reads ALL the text of a card in the chosen language (en / hi / or / ur).
   1) server voice (POST /api/tts, mp3) - works even when the phone has no Odia/Urdu voice;  2) the phone's own speech voice. ---- */
const LK={en:'en-IN',hi:'hi-IN',or:'or-IN',ur:'ur-PK'};
const VO={tok:0,bad:{},cache:new Map(),res:null,AU:new Audio()};
const END=/[.!?\u0964\u06d4\u061f]$/,sent=x=>{x=String(x).trim();return END.test(x)?x:x+'.'};
function chunkText(t,n=200){const out=[];let cur='';(String(t).match(/[^.!?\u0964\u06d4\u061f]+[.!?\u0964\u06d4\u061f]*\s*/g)||[t]).forEach(p=>{if(cur&&cur.length+p.length>n){out.push(cur.trim());cur=''}cur+=p});if(cur.trim())out.push(cur.trim());return out}
/* phones (iOS) only allow audio after a tap: unlock the audio element once on the first touch */
addEventListener('pointerdown',()=>{if(VO.ok)return;VO.ok=1;VO.AU.src='data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';VO.AU.play().catch(()=>{})},{once:true});
function stopSpeech(){VO.tok++;try{window.speechSynthesis&&speechSynthesis.cancel();VO.AU.pause()}catch{}if(VO.res){VO.res();VO.res=null}document.body.classList.remove('speaking')}
function srvAudio(txt,k){const key=k+'|'+txt;if(!VO.cache.has(key)){if(VO.cache.size>80)VO.cache.delete(VO.cache.keys().next().value);
  VO.cache.set(key,fetch(API+'/api/tts',{method:'POST',headers:DB.h(),body:JSON.stringify({text:txt,lang:k})}).then(r=>{if(!r.ok)throw 0;return r.blob()}).then(b=>URL.createObjectURL(b)).catch(()=>{VO.cache.delete(key);return null}))}
  return VO.cache.get(key)}
function playUrl(u,tok){return new Promise(res=>{VO.res=res;const A=VO.AU;A.onended=()=>res();A.onerror=()=>res('err');A.src=u;A.play().catch(()=>res('err'))}).then(r=>{VO.res=null;return r!=='err'})}
/* Odia script -> Devanagari so a Hindi voice can read it when the phone has no Odia voice (same offset layout) */
function or2hi(s){const O={0x2F:0x91C,0x5F:0x92F,0x33:0x932,0x71:0x935};return s.replace(/[\u0B01-\u0B77]/g,c=>{const x=c.charCodeAt(0)-0xB00;return String.fromCharCode(O[x]||0x900+x)})}
function phoneSpeak(parts,k,tok){return new Promise(res=>{const syn=window.speechSynthesis;if(!syn)return res();
  const vs=syn.getVoices(),p=LK[k].toLowerCase();let v=vs.find(x=>x.lang.replace('_','-').toLowerCase()===p)||vs.find(x=>x.lang.toLowerCase().startsWith(p.slice(0,2)))||null,tr=false;
  if(!v&&k==='or'){tr=true;v=vs.find(x=>x.lang.toLowerCase().startsWith('hi'))||null;noVoice('or2');if(vs.length&&!v)return res()}   // no Odia voice: Hindi voice reads the Odia text (approximate)
  else if(!v&&vs.length&&k!=='en'){noVoice(k);return res()}       // never read Hindi/Urdu text with a wrong voice
  let i=0;const next=()=>{if(tok!==VO.tok||i>=parts.length)return res();const q=parts[i++],u=new SpeechSynthesisUtterance(tr?or2hi(q):q);u.lang=tr?'hi-IN':LK[k];u.rate=.95;try{if(v)u.voice=v}catch{}u.onend=next;u.onerror=next;syn.speak(u)};next()})}
function speak(txt,lg){if(!txt)return;stopSpeech();const tok=VO.tok,k=lg||S.lang,parts=chunkText(txt);
  document.body.classList.add('speaking');
  setTimeout(async()=>{if(tok!==VO.tok)return;
    for(let i=0;i<parts.length;i++){
      if(tok!==VO.tok)return;
      let ok=false;
      if(!VO.bad[k]||Date.now()-VO.bad[k]>45000){const u=await srvAudio(parts[i],k);if(parts[i+1])srvAudio(parts[i+1],k);   // fetch next chunk while this one plays
        if(tok!==VO.tok)return;ok=u?await playUrl(u,tok):false;if(!ok)VO.bad[k]=Date.now()}
      if(tok!==VO.tok)return;
      if(!ok){await phoneSpeak(parts.slice(i),k,tok);break}}
    if(tok===VO.tok)document.body.classList.remove('speaking')},60)}
/* one small notice per language when neither the server nor the phone can speak it */
function noVoice(k){S.nv=S.nv||{};if(S.nv[k])return;S.nv[k]=1;const d=document.createElement('div');d.className='toast';d.textContent='🔇 '+t(k==='or2'?'noVoiceOr':'noVoice');$('#app').append(d);setTimeout(()=>d.remove(),6000)}
/* text with no local-script letters (e.g. an English fallback) is read with the English voice */
function speakAuto(txt){speak(txt,S.lang!=='en'&&!/[^\x00-\x7F]/.test(txt)?'en':undefined)}
const stepTxt=s=>s[li()+1]||s[1];
function fmt(r){
  if(r.corrected!==undefined)return `✅ <b>${esc(r.corrected)}</b><ul>${(r.notes||[]).map(n=>`<li>${esc(n)}</li>`).join('')}</ul>`;
  return `<div style="font-size:42px">${r.icon||'💡'}</div><ol>${r.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>`+
    `<div class="sum"><b>${t('learned')}:</b> ${esc(r.summary||'')}</div><p class="sm">${t('follow')}</p>`+(r.followups||[]).map(q=>`<span class="fq" data-q="1">${esc(q)}</span>`).join('')+` <button class="fq" data-say>🔊</button>`;
}
function localAnswer(q){return{icon:'💡',steps:[`Define "${q}" in one sentence.`,'Try one small example yourself.','Explain it back in your own words.'],followups:[`Can you give an example of ${q}?`,'What is the most common mistake?'],summary:`You learned the basics of ${q} and practised it once.`}}
function chatOpen(){            // greeting + the follow-up questions Auralis added by itself after finished lessons
  const m=$('#msgs');if(!m.children.length)bubble('bot',esc(t('chatHi')));
  if(S.followNew&&S.follow.length){S.followNew=false;bubble('bot',`<b>💬 ${t('followT')}</b><div>${chips(S.follow.slice(-6))}</div>`)}
  setTimeout(()=>$('#cIn').focus(),350);
}
async function ask(text){
  text=(text||'').trim();if(!text||S.busy)return;S.busy=true;$('#cIn').value='';bubble('me',esc(text));logEv('question');
  const b=bubble('bot',`<span class="typing"><i></i><i></i><i></i></span>`);let r;
  try{const x=await fetch(API+(S.grammar?'/api/grammar':'/api/chat'),{method:'POST',headers:DB.h(),body:JSON.stringify({text,lang:S.lang}),signal:window.AbortSignal&&AbortSignal.timeout?AbortSignal.timeout(45000):undefined});
    if(!x.ok)throw 0;r=await x.json();if(S.grammar?typeof r.corrected!=='string':!Array.isArray(r.steps))throw 0}
  catch{r=S.grammar?{corrected:text.charAt(0).toUpperCase()+text.slice(1),notes:['(offline demo)']}:localAnswer(text)}
  S.busy=false;b.innerHTML=fmt(r);b._say=r.corrected??r.steps.join('. ');window.orbBoost&&orbBoost();$('#msgs').scrollTop=$('#msgs').scrollHeight;
}
$('#msgs').onclick=e=>{const s=e.target.closest('[data-say]');if(s){const b=s.closest('.m');b&&b._say&&speak(b._say)}};
$('#cSend').onclick=()=>ask($('#cIn').value);
/* NOTE: never return false from a key handler - that cancels typing. (This was the "chat does not take input" bug.) */
$('#cIn').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();ask(e.target.value)}});
$('#gBtn').onclick=e=>{S.grammar=!S.grammar;e.currentTarget.classList.toggle('on',S.grammar)};
$('#mic').onclick=()=>{const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R)return bubble('bot','Voice input is not supported in this browser.');
  const r=new R();r.lang=SPEECH[S.lang];r.onresult=e=>ask(e.results[0][0].transcript);r.onerror=e=>bubble('bot','🎤 '+(e.error||'error'));try{r.start()}catch{}};
$('#media').onchange=e=>{const f=e.target.files[0];if(!f)return;const u=URL.createObjectURL(f);
  bubble('me',f.type.startsWith('video')?`<video src="${u}" controls></video>`:`<img src="${u}">`);
  bubble('bot','📎 Demo: send this file to the backend (/api/chat) for image or video analysis and text extraction.')};

applyLang();
