# Auralis by EduNexus (3D animated, HD)

```
auralis/
├─ frontend/            index.html · css/style.css · js/data.js (languages + lessons) · js/app.js
└─ backend/             main.py (FastAPI) · requirements.txt
```

## Run
**Everything (recommended):**
```
cd backend && pip install -r requirements.txt && uvicorn main:app --reload
```
Open http://localhost:8000

**Frontend only (Node):** `cd frontend && npm start` → http://localhost:3000. Chat falls back to a local demo answer when the backend is off; with the backend on, run it on port 8000 too.

## Notes
- Prototype screens run on dummy data; the chatbot calls `/api/chat` and `/api/grammar`.
- Auth (`/api/auth/signup`, `/api/auth/verify`, demo OTP `1234`) and progress (`/api/progress`) exist in the backend but are not wired into the UI yet.
- Lessons: full text in English, Hindi and Odia. Urdu menus are translated; Urdu lesson steps show English.
- `generate_answer()` in `main.py` is the place to plug in a real LLM.

- 3D version: needs internet (Three.js + fonts load from CDN). Orb scene: js/scene3d.js
- Home: robot guide + plans banner. Plans screen (js/extras.js): Basic Rs199, Medium Rs299, Premium Rs399, each for 3 months (feature lists are placeholders; payment is not connected).

## Database (Neo4j) - every student's data is stored
Stored per student: profile, language, categories, completed lessons, reminders, plan, chat questions (graph model in `backend/db.py`).
1. Start Neo4j: `cd backend && docker compose up -d`  (or use Neo4j Desktop and set NEO4J_URI / NEO4J_USER / NEO4J_PASSWORD)
2. `pip install -r requirements.txt && python -m uvicorn main:app --reload`
3. Check http://localhost:8000/api/health -> `"db":"neo4j"`. If it says `memory`, Neo4j was not reachable and data is lost on restart.
4. See the data: http://localhost:7474 (login neo4j / auralis123), queries in `backend/schema.cypher`.
5. Admin list of all students: GET /api/admin/students with header `x-admin-key: admin123`.
Login with the same email/phone again (OTP 1234 while the backend is on) and the student's saved data loads back.

## Growth Coach (AI agent)
Progress screen -> "Growth Coach": average growth per week (week-over-week %), points and lessons per week, a weekly bar chart, best week, streak, and a spoken/written coaching message in the student's language.
- Points: 10 per completed lesson, 2 per chatbot question. Data comes from the timestamps stored in Neo4j. API: `GET /api/me/growth?lang=hi` (`&demo=1` for a sample report).
- Tap the Growth Coach card -> full-screen **3D scene**: talking 3D robot coach, rising 3D weekly bars, trend arrow, sparkles, and the typed answer (🔊 to hear it, drag to rotate). Works with backend data or local data.
- With an AI key set (see below) the AI writes the message; otherwise built-in rule-based text is used.


## OpenAI key (real AI answers)
1. `cd backend && cp .env.example .env`
2. Open `backend/.env` and paste your key: `OPENAI_API_KEY=sk-...` (optional `OPENAI_MODEL=gpt-4o-mini`)
3. `pip install -r requirements.txt` and restart: `python -m uvicorn main:app --reload`
4. Check http://localhost:8000/api/health -> `"llm":"openai"` (`"rules"` = no key found; `llm_error` shows why a call failed).
The key lives only on the server (never in the browser files). Without a key / on any error, every feature falls back to built-in answers.
It powers: chat answers, grammar fixes, auto follow-up questions, exam-plan questions/tips, Growth Coach message.
(No OpenAI key? `ANTHROPIC_API_KEY=` works too, only used when the OpenAI key is empty.)

## Auto exam plan + auto follow-up questions
- After every lesson, follow-up questions are added automatically (completion screen + chat).
- When the student finishes ALL lessons, the exam plan is built automatically: day-by-day revise -> practice -> mock test -> exam day, with a reminder for every day. Date can be changed on the Exam plan screen (3-30 days). Home shows the Exam plan card (locked until the course is done).

## Chat input fix
`onkeydown=e=>e.key==='Enter'&&ask()` returned `false` for every other key, which cancels typing. Now a proper listener; messages scroll inside the chat box.

## Update: voice lessons, new lessons, AI Coach
- **Phone privacy:** phone number is typed as dots (👁️ to peek) and shown as `••••••••10` in Profile.
- **New lessons:** Python Basics, History Basics (Ancient to Independent India), Stock Market Basics. English + Hindi text; Odia/Urdu show English for these.
- **Voice in every lesson:** each step is read aloud automatically (🔔 toggle) and with the 🔊 Listen button. Uses the browser's speech voices (hi-IN, en-IN, or-IN, ur-PK). If a device has no Odia voice it falls back to its default.
- **AI Coach** (Home -> 🧠 AI Coach, `js/ai.js`, works offline, results saved per student):
  1. Learning Gap Detector - weak/okay/strong per topic from quiz results, recently missed questions, one-tap practice.
  2. Adaptive Question Generator - pick topic + level (Auto/Easy/Medium/Hard); questions come from the lesson syllabus and your past mistakes come first.
  3. Exam Rescue Plan - exam date + hours/day; unfinished and weak topics first, skips low-value revision when behind, mock test + exam day, one tap to add reminders.
  4. Knowledge Mastery Map - topic graph with mastery rings, links between related topics, tap a topic to learn/revise/practice.
- Quiz questions are English only for now.

## Update: 4-language lessons + voice
- Language cards no longer show the "Learn in English / हिन्दी में सीखें / ..." subtitle lines.
- All 8 lessons (title, materials, every step, tip) now exist in English, Hindi, Odia and Urdu. Home "Recommended", Explore, Reminders, Exam plan and Growth Coach all follow the selected language.
- Lesson data format (js/data.js): step = `[icon, en, hi, or, ur, tip?]`, title = `[en, hi, or, ur]`, material = `[icon, en, hi, or, ur]`.
- Voice speaks in the selected language (en-IN, hi-IN, or-IN, ur-PK) using the device's built-in voices. If a device has no voice for that language, a one-time notice explains how to install it (phone Settings > Text-to-speech). Odia voices are missing on many devices.
- AI Coach: menu titles are translated to all 4 languages; quiz questions from the fixed question bank are still English (questions built from lesson steps follow the selected language).

## Voice in 4 languages (English, Hindi, Odia, Urdu)
Every lesson card is read aloud completely in the selected language: "Step 4 of 5", the lesson text and the tip; the materials card reads the title and all materials; the last card reads "Lesson complete". Long text is read in sentence chunks, so nothing is cut off.

How it works (js/app.js, backend/voice.py):
1. The app asks the server `POST /api/tts` for an mp3 in the chosen language (works even if the phone has no Odia/Urdu voice).
2. If the server is off, the app uses the phone's own voice. If the phone has no voice for that language, a one-time notice says how to install it (Settings > Text-to-speech) and the text is NOT read with a wrong voice.

To get real Odia + Urdu + Hindi voices on every phone:
1. `cd backend && pip install -r requirements.txt`
2. Create a free Azure "Speech" resource, then in `backend/.env` set `AZURE_SPEECH_KEY=...` and `AZURE_SPEECH_REGION=centralindia` (voices used: en-IN-Neerja, hi-IN-Swara, or-IN-Subhasini, ur-PK-Uzma).
   Without a key, edge-tts / gTTS (free) speak English, Hindi and Urdu; Odia needs Azure.
3. Check http://localhost:8000/api/tts/status
4. Optional: `python precache_voice.py` pre-generates every lesson sentence in all 4 languages (stored in backend/tts_cache), so lessons play instantly.

### Odia voice - what you will hear
1. **Azure key set on the server** -> real Odia voice (or-IN-Subhasini).
2. **No Azure key** -> the Odia text is converted to Devanagari (same Brahmic letter layout) and read with a **Hindi** voice. This is an *approximation* (Hindi accent, some Odia sounds differ) but it is clearly audible and understandable. It works two ways: on the server (needs `edge-tts` or `gTTS`) and, if the server is off, with the phone's own Hindi voice. A notice in Odia tells the student when this is happening.
3. If the device has no Hindi voice either, the notice appears and nothing is read.
Check `http://localhost:8000/api/tts/status` (`odia_real_voice`, `odia_hindi_approx`).
