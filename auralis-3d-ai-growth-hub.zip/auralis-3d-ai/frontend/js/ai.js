/* AI Coach: Learning Gap Detector, Adaptive Question Generator, Exam Rescue Plan, Knowledge Mastery Map.
   Runs fully in the browser (no backend needed). Quiz results are saved per student in localStorage. */
Object.assign(T.en,{aiCoach:'AI Coach',aiSub:'Quizzes, gaps, rescue plan, map',gapT:'Learning Gap Detector',gapD:'Finds weak topics from your quiz results',genT:'Adaptive Questions',genD:'Made from topic, level and your past mistakes',resT:'Exam Rescue Plan',resD:'Re-plans your study when you fall behind',mapT:'Knowledge Mastery Map',mapD:'See what you know and what needs revision',
 listen:'Listen',auto:'Auto voice',qAfter:'In this lesson, what comes right after: "{a}"?',qOdd:'Which step does NOT belong to this lesson?',topic:'Topic',level:'Level',auto2:'Auto',easy:'Easy',med:'Medium',hard:'Hard',startQ:'Start quiz',qN:'Question {n} of {m}',right:'Correct!',wrong:'Not quite. Answer:',nextQ:'Next',seeRes:'See result',score:'Your score',weak:'Weak',ok:'Okay',strong:'Strong',nw:'Not tested',todo:'Not learned yet',noData:'Take a quiz first. Auralis will find your weak topics.',prac:'Practice',learn:'Learn',missed:'Recently missed',taken:'answers',acc:'accuracy',
 exDate:'Exam date',hrs:'Hours per day',mk:'Make rescue plan',onTrack:'You are on track.',behind:'You are behind. Auralis squeezed the plan to what matters most.',skipped:'Skipped for now',apply:'Add to reminders',applied:'Reminders added!',day:'Day',rs_learn:'Learn',rs_fix:'Fix weak topic',rs_recap:'Recap',rs_skim:'Quick skim',mockD:'Full mock test',examD:'Exam day. Stay calm!',rel:'Related',back2:'Back',retry:'Try again',more:'More questions',mins:'min'});
Object.assign(T.hi,{aiCoach:'AI कोच',aiSub:'क्विज़, कमज़ोरी, रेस्क्यू प्लान, मैप',gapT:'सीखने की कमी पहचानें',gapD:'क्विज़ से कमज़ोर विषय खोजता है',genT:'अनुकूली सवाल',genD:'विषय, स्तर और पिछली गलतियों से बने सवाल',resT:'परीक्षा रेस्क्यू प्लान',resD:'पीछे रहने पर पढ़ाई की योजना बदलता है',mapT:'ज्ञान मानचित्र',mapD:'देखिए क्या आता है और क्या दोहराना है',
 listen:'सुनें',auto:'अपने-आप आवाज़',qAfter:'इस पाठ में "{a}" के ठीक बाद क्या आता है?',qOdd:'कौन सा चरण इस पाठ का नहीं है?',topic:'विषय',level:'स्तर',auto2:'ऑटो',easy:'आसान',med:'मध्यम',hard:'कठिन',startQ:'क्विज़ शुरू करें',qN:'सवाल {n}/{m}',right:'सही!',wrong:'ग़लत। उत्तर:',nextQ:'अगला',seeRes:'नतीजा देखें',score:'आपका स्कोर',weak:'कमज़ोर',ok:'ठीक',strong:'मज़बूत',nw:'टेस्ट नहीं हुआ',todo:'अभी सीखा नहीं',noData:'पहले एक क्विज़ दीजिए। ऑरालिस आपके कमज़ोर विषय खोज लेगा।',prac:'अभ्यास',learn:'सीखें',missed:'हाल की ग़लतियाँ',taken:'उत्तर',acc:'सटीकता',
 exDate:'परीक्षा की तारीख़',hrs:'रोज़ के घंटे',mk:'रेस्क्यू प्लान बनाएँ',onTrack:'आप सही रास्ते पर हैं।',behind:'आप पीछे हैं। ऑरालिस ने योजना को सबसे ज़रूरी चीज़ों तक सीमित कर दिया।',skipped:'अभी छोड़ा गया',apply:'रिमाइंडर में जोड़ें',applied:'रिमाइंडर जुड़ गए!',day:'दिन',rs_learn:'सीखें',rs_fix:'कमज़ोर विषय सुधारें',rs_recap:'दोहराव',rs_skim:'तेज़ नज़र',mockD:'पूरा मॉक टेस्ट',examD:'परीक्षा का दिन। शांत रहिए!',rel:'जुड़े विषय',back2:'पीछे',retry:'फिर कोशिश',more:'और सवाल',mins:'मिनट'});

Object.assign(T.en,{noVoiceOr:'No Odia voice found. Reading with a Hindi voice (approximate). For real Odia, set up the Azure voice key on the server.',noVoice:'This device has no voice for this language. Add it in phone Settings > Text-to-speech.'});
Object.assign(T.hi,{noVoiceOr:'ओड़िया आवाज़ नहीं मिली। हिन्दी आवाज़ में पढ़ रहा हूँ (अनुमानित)। असली ओड़िया के लिए सर्वर पर Azure कुंजी लगाएँ।',noVoice:'इस डिवाइस में इस भाषा की आवाज़ नहीं है। फ़ोन सेटिंग्स > टेक्स्ट-टू-स्पीच में जोड़ें।'});
Object.assign(T.or,{noVoiceOr:'ଓଡ଼ିଆ ସ୍ୱର ମିଳିଲା ନାହିଁ। ହିନ୍ଦୀ ସ୍ୱରରେ ପଢ଼ାଯାଉଛି (ଆନୁମାନିକ)। ପ୍ରକୃତ ଓଡ଼ିଆ ପାଇଁ ସର୍ଭରରେ Azure କି ଲଗାନ୍ତୁ।',noVoice:'ଏହି ଡିଭାଇସରେ ଏହି ଭାଷାର ସ୍ୱର ନାହିଁ। ଫୋନ୍ ସେଟିଂସ୍ > ଟେକ୍ସଟ୍-ଟୁ-ସ୍ପିଚ୍ ରେ ଯୋଗ କରନ୍ତୁ।',listen:'ଶୁଣନ୍ତୁ',auto:'ସ୍ୱୟଂଚାଳିତ ସ୍ୱର',aiCoach:'AI କୋଚ୍',aiSub:'କୁଇଜ୍, ଦୁର୍ବଳତା, ରକ୍ଷା ଯୋଜନା, ମାନଚିତ୍ର',gapT:'ଶିକ୍ଷଣ ଅଭାବ ଚିହ୍ନଟ',genT:'ଅନୁକୂଳ ପ୍ରଶ୍ନ',resT:'ପରୀକ୍ଷା ରକ୍ଷା ଯୋଜନା',mapT:'ଜ୍ଞାନ ମାନଚିତ୍ର'});
Object.assign(T.ur,{noVoiceOr:'اڑیہ آواز نہیں ملی۔ ہندی آواز میں پڑھا جا رہا ہے (تخمینی)۔',noVoice:'اس ڈیوائس میں اس زبان کی آواز موجود نہیں۔ فون سیٹنگز > ٹیکسٹ ٹو اسپیچ میں شامل کریں۔',listen:'سنیں',auto:'خودکار آواز',aiCoach:'AI کوچ',aiSub:'کوئز، کمزوری، ریسکیو پلان، نقشہ',gapT:'سیکھنے کی کمی کی نشاندہی',genT:'موافق سوالات',resT:'امتحانی ریسکیو پلان',mapT:'علمی نقشہ'});

/* wording used only for the spoken voice ("4/5" would be read as a fraction) */
Object.assign(T.en,{stepSay:'Step {n} of {m}'});Object.assign(T.hi,{stepSay:'चरण {n}, कुल {m} चरणों में से'});
Object.assign(T.or,{stepSay:'ପଦକ୍ଷେପ {n}, ମୋଟ {m} ପଦକ୍ଷେପ ମଧ୍ୟରୁ'});Object.assign(T.ur,{stepSay:'مرحلہ {n} از {m}'});

/* ---- question bank: [question, [options, correct one first], explanation-free] ---- */
const QB={
 paint:[['What do you draw first for the flower centre?',['A circle','A square','A triangle','A star']],['What goes around the centre circle?',['Petals','Wheels','Windows','Roofs']],['What should you do before adding the yellow centre?',['Let the paint dry','Tear the paper','Add more water','Rub hard']]],
 boat:[['Which paper does the boat lesson need?',['Square paper','Wet cloth','Cardboard box','Metal sheet']],['Why make sharp folds?',['So the boat holds its shape','To tear the paper','For colour','No reason']],['What helps a paper boat float?',['Its folded shape traps air','Glue','Stones','Heat']]],
 stretch:[['How long is the morning stretch?',['5 minutes','1 hour','30 seconds','2 hours']],['How should you breathe while stretching?',['Slow and deep','Hold your breath','Very fast','Not at all']],['Which time suits this routine?',['Morning','Midnight','Right after a heavy meal','Only on exam day']]],
 sing:[['Why warm up your voice?',['To protect it and sing easily','To shout louder','To fall asleep','To whisper']],['What should you keep nearby?',['A glass of water','Spicy snacks','Soda','Chalk']],['"Sa Re Ga Ma" belongs to which field?',['Music','Football','Chess','Painting']]],
 words:[['How many basic words does this lesson teach?',['10','100','2','50']],['Which of these is a greeting?',['Hello','Water','Three','Friend']],['What is a good way to remember new words?',['Say them aloud','Never speak','Skip practice','Read once']]],
 python:[['Which line shows a message on screen?',['print("Hi")','say Hi','show Hi','echo Hi']],['In age = 18, what is "age"?',['A variable','A loop','A comment','A printer']],['Which keyword repeats work in a loop?',['for','else','pass','import']],['Which keyword helps the program decide?',['if','range','print','var']]],
 history:[['Which was a planned city of the Indus Valley Civilisation?',['Harappa','Kolkata','Chennai','Pune']],['In which year did India become independent?',['1947','1857','1950','1930']],['Who led the Salt March in 1930?',['Mahatma Gandhi','Ashoka','Akbar','Robert Clive']],['After which war did Ashoka choose peace?',['Kalinga','Plassey','Panipat','Buxar']]],
 stock:[['What is a share?',['A part ownership of a company','A bank loan','A tax','A bill']],['Which body regulates the Indian share market?',['SEBI','FIFA','UNESCO','ISRO']],['Which is a good safety rule?',['Spread money across many companies','Put all money in one share','Borrow money to invest','Follow rumours']],['Which two are stock exchanges in India?',['NSE and BSE','RBI and LIC','ISRO and DRDO','IIT and NIT']]]};
const LINKS=[['paint','boat'],['stretch','sing'],['words','history'],['python','stock'],['history','stock'],['words','sing'],['paint','sing'],['python','words']];
const SUBJ={paint:'🎨',boat:'🎨',stretch:'🧘',sing:'🧘',words:'💻',python:'💻',history:'✨',stock:'✨'};

const AI={res:[],view:'hub',q:null,id:'paint',lv:'auto',hrs:2,plan:null,sel:null};
const AK=()=>'aur_ai_'+(S.user.contact||'guest');
function aiLoad(){try{AI.res=JSON.parse(localStorage.getItem(AK())||'[]')}catch{AI.res=[]}}
function aiSave(){try{localStorage.setItem(AK(),JSON.stringify(AI.res.slice(-300)))}catch{}}
const shuf=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const mk=o=>{const r=shuf(o.map((x,i)=>[x,!i]));return{o:r.map(x=>x[0]),a:r.findIndex(x=>x[1])}};
const stx=(L,i)=>{const s=L.steps[i];return s[li()+1]||s[1]};
const LES=id=>LESSONS.find(l=>l.id===id);

/* ---- mastery statistics per lesson ---- */
function stats(){const m={};LESSONS.forEach(l=>m[l.id]={n:0,r:0,d:S.done.has(l.id),p:null,st:S.done.has(l.id)?'nw':'todo'});
 const by={};AI.res.forEach(x=>{(by[x.id]=by[x.id]||[]).push(x)});
 Object.keys(by).forEach(id=>{const s=m[id];if(!s)return;const a=by[id],rc=a.slice(-5);s.n=a.length;s.r=a.filter(x=>x.ok).length;
  if(s.n>=2){const all=s.r/s.n,rec=rc.filter(x=>x.ok).length/rc.length;s.p=Math.round(100*(.4*all+.6*rec));s.st=s.p>=80?'strong':s.p>=55?'ok':'weak'}else s.st=s.d?'nw':'todo'});
 return m}

/* ---- Adaptive Question Generator: topic + level + syllabus (lesson steps) + past mistakes ---- */
function genQs(id,lv,n){
 const L=LES(id),st=stats()[id];
 if(lv==='auto')lv=st.p===null?1:st.p>=80?3:st.p>=55?2:1;
 const bank=(QB[id]||[]).map((b,i)=>({k:id+':b'+i,id,lv:1,q:b[0],...mk(b[1])}));
 const ord=[];for(let i=1;i<L.steps.length;i++){const w=shuf(L.steps.map((_,j)=>j).filter(j=>j!==i)).slice(0,3);ord.push({k:id+':s'+i,id,lv:2,q:t('qAfter').replace('{a}',stx(L,i-1)),...mk([stx(L,i),...w.map(j=>stx(L,j))])})}
 const hard=[];for(let m=0;m<3;m++){const o=shuf(LESSONS.filter(x=>x.id!==id))[m%7%(LESSONS.length-1)];hard.push({k:id+':h'+m,id,lv:3,q:t('qOdd'),...mk([stx(o,m%o.steps.length),...shuf(L.steps.map((_,j)=>j)).slice(0,3).map(j=>stx(L,j))])})}
 const all=[...bank,...ord,...hard],last={};AI.res.forEach(x=>last[x.k]=x.ok);
 const mist=shuf(all.filter(q=>last[q.k]===false)),rest=all.filter(q=>last[q.k]!==false);
 const same=shuf(rest.filter(q=>q.lv===lv)),other=shuf(rest.filter(q=>q.lv!==lv));
 const seen=q=>last[q.k]===undefined?0:1;           // unseen questions first
 return[...mist,...same.sort((a,b)=>seen(a)-seen(b)),...other].slice(0,n)}
function startQuiz(id,lv){AI.id=id;AI.lv=lv||AI.lv;const list=genQs(id,AI.lv,5);AI.q={list,i:0,score:0,done:false};AI.sel=null;AI.view='quiz';aiScreen()}
function sayQ(){const c=AI.q.list[AI.q.i];speakAuto(c.q+'. '+c.o.map((x,i)=>(i+1)+'. '+x).join('. '))}

/* ---- Exam Rescue Plan ---- */
function rescue(date,hrs){
 const today=new Date();today.setHours(0,0,0,0);
 let n=Math.round((new Date(date+'T00:00:00')-today)/864e5);n=Math.max(1,Math.min(n,30));
 const st=stats(),cap=hrs*60,K={learn:[25,0],fix:[20,1],recap:[12,2],skim:[5,3]};
 const tasks=LESSONS.map(l=>{const s=st[l.id],k=!s.d?'learn':s.st==='weak'?'fix':s.st==='strong'?'skim':'recap';return{id:l.id,k,m:K[k][0],p:K[k][1]}}).sort((a,b)=>a.p-b.p);
 const usable=n>=3?n-2:n>=2?n-1:1,days=[];
 for(let i=1;i<=n;i++){const date2=iso(addDays(today,i));days.push({n:i,date:date2,min:0,tasks:[],type:i>usable?(i===n&&n>=2?'exam':'mock'):'study'})}
 if(n===1)days[0].type='study';
 const skipped=[];let d=0;
 tasks.forEach(k=>{while(d<usable&&days[d].min+k.m>cap)d++;if(d>=usable)skipped.push(k);else{days[d].tasks.push(k);days[d].min+=k.m}});
 const need=tasks.reduce((a,k)=>a+k.m,0),behind=tasks.some(k=>k.k==='learn')&&(skipped.length>0||need>cap*usable*.8);
 return{n,days,skipped,behind,date}}
function applyRescue(){const p=AI.plan;if(!p)return;
 S.rem.filter(r=>String(r.id).startsWith('rs')).forEach(r=>DB.delRem(r.id));S.rem=S.rem.filter(r=>!String(r.id).startsWith('rs'));
 p.days.forEach(d=>{const r={id:'rs'+d.n+Date.now().toString(36),a:d.tasks[0]?d.tasks[0].id:'exam',d:d.date,t:'18:00',rep:'once',on:true};S.rem.push(r);DB.addRem(r)});
 persist();AI.applied=1;aiScreen()}

/* ---- rendering ---- */
const SC={weak:'#ff7a8a',ok:'#ffc857',strong:'#5fd39a',nw:'#c9b8f5',todo:'#e6dcff'};
const bar=(p,c)=>`<div class="abar"><b style="width:${p||0}%;background:${c}"></b></div>`;
function head(title,back){return`<div class="aihd"><button class="btn ghost small" data-ai="${back?'hub':'home'}">←</button><h2>${title}</h2></div>`}
function aiScreen(){
 const box=$('#aiBody');if(!box)return;if(S.cur==='ai'&&AI.view==='hub'&&!AI._l){AI._l=1}aiLoad();const st=stats();
 const v=AI.view;let h='';
 if(v==='hub'){const n=AI.res.length,ok=AI.res.filter(x=>x.ok).length;
  h=head('🧠 '+t('aiCoach'))+`<div class="card"><b>${n}</b> ${t('taken')} · <b>${n?Math.round(100*ok/n):0}%</b> ${t('acc')}</div>`+
  [['gaps','🔍','gapT','gapD'],['gen','🎯','genT','genD'],['resc','🛟','resT','resD'],['map','🕸️','mapT','mapD']].map((x,i)=>`<div class="card item aitile" style="animation-delay:${i*.07}s" data-ai="${x[0]}"><span class="ic">${x[1]}</span><div><b>${t(x[2])}</b><p class="sm">${t(x[3])}</p></div></div>`).join('')}
 else if(v==='gen'){h=head('🎯 '+t('genT'),1)+`<div class="card"><label>${t('topic')}</label><select id="aiTopic">${LESSONS.map(l=>`<option value="${l.id}" ${l.id===AI.id?'selected':''}>${SUBJ[l.id]} ${l.title[li()]}</option>`).join('')}</select>
  <label>${t('level')}</label><div class="chips">${[['auto','auto2'],['1','easy'],['2','med'],['3','hard']].map(x=>`<button class="${String(AI.lv)===x[0]?'on':''}" data-lv="${x[0]}">${t(x[1])}</button>`).join('')}</div><button class="btn" data-ai="start">${t('startQ')}</button></div>`}
 else if(v==='quiz'){const Q=AI.q;
  if(Q.done){const pc=Math.round(100*Q.score/Q.list.length);h=head('🎯 '+t('score'),1)+`<div class="card c"><div class="big">${pc>=80?'🏆':pc>=50?'👍':'💪'}</div><h2>${Q.score} / ${Q.list.length}</h2>${bar(pc,pc>=80?SC.strong:pc>=50?SC.ok:SC.weak)}</div><button class="btn" data-ai="start">${t('retry')}</button><button class="btn ghost" data-ai="gaps">🔍 ${t('gapT')}</button>`;speakAuto(t('score')+' '+Q.score+' / '+Q.list.length)}
  else{const c=Q.list[Q.i];h=head('🎯 '+LES(c.id).title[li()],1)+`<div class="bar"><b style="width:${(Q.i+1)/Q.list.length*100}%"></b></div><p class="sm">${t('qN').replace('{n}',Q.i+1).replace('{m}',Q.list.length)}</p><div class="card"><p class="txt">${esc(c.q)}</p><button class="fq" data-ai="sayq">🔊 ${t('listen')}</button></div>`+
   c.o.map((o,i)=>`<button class="ans ${AI.sel===null?'':i===c.a?'good':i===AI.sel?'bad':''}" data-a="${i}" ${AI.sel===null?'':'disabled'}>${esc(o)}</button>`).join('')+
   (AI.sel===null?'':`<div class="tip">${AI.sel===c.a?'✅ '+t('right'):'❌ '+t('wrong')+' <b>'+esc(c.o[c.a])+'</b>'}</div><button class="btn" data-ai="nextq">${Q.i===Q.list.length-1?t('seeRes'):t('nextQ')}</button>`)}}
 else if(v==='gaps'){const rows=LESSONS.map(l=>({l,s:st[l.id]})).sort((a,b)=>({weak:0,nw:1,todo:2,ok:3,strong:4}[a.s.st]-{weak:0,nw:1,todo:2,ok:3,strong:4}[b.s.st]));
  const miss=AI.res.filter(x=>!x.ok).slice(-3).reverse();
  h=head('🔍 '+t('gapT'),1)+(AI.res.length?'':`<div class="card">${t('noData')}</div>`)+rows.map(({l,s},i)=>`<div class="card gap" style="animation-delay:${i*.05}s"><div class="row2"><span class="ic">${l.icon}</span><div class="grow"><b>${l.title[li()]}</b>${bar(s.p===null?(s.d?10:0):s.p,SC[s.st])}</div><span class="pill" style="background:${SC[s.st]}">${s.p===null?'–':s.p+'%'}</span></div><p class="sm">${t(s.st)}${s.n?' · '+s.r+'/'+s.n:''}</p><button class="fq" data-ai="prac" data-id="${l.id}">🎯 ${t('prac')}</button>${s.d?'':`<button class="fq" data-ai="learn" data-id="${l.id}">▶ ${t('learn')}</button>`}</div>`).join('')+
  (miss.length?`<h3>${t('missed')}</h3>`+miss.map(x=>`<div class="card sm">❌ ${esc(x.q)}</div>`).join(''):'')}
 else if(v==='resc'){const dflt=(S.exam&&S.exam.date)||iso(addDays(new Date(),7));AI.date=AI.date||dflt;
  h=head('🛟 '+t('resT'),1)+`<div class="card"><label>${t('exDate')}</label><input type="date" id="rsDate" value="${AI.date}" min="${iso(addDays(new Date(),1))}" max="${iso(addDays(new Date(),30))}"><label>${t('hrs')}</label><div class="chips">${[1,2,3,4].map(x=>`<button class="${AI.hrs===x?'on':''}" data-h="${x}">${x}</button>`).join('')}</div><button class="btn" data-ai="mkplan">${t('mk')}</button></div>`;
  const p=AI.plan;if(p)h+=`<div class="card ${p.behind?'warn':'okc'}">${p.behind?'⚠️ '+t('behind'):'✅ '+t('onTrack')}</div>`+p.days.map((d,i)=>`<div class="card eday ${d.type==='study'?'':'mock'}" style="animation-delay:${i*.04}s"><b>${t('day')} ${d.n} · ${d.date}</b>${d.type==='study'?` <span class="sm">${d.min} ${t('mins')}</span><ul>${d.tasks.map(k=>`<li>${t('rs_'+k.k)}: ${LES(k.id).title[li()]} <span class="sm">(${k.m} ${t('mins')})</span></li>`).join('')}</ul>`:`<p>${d.type==='exam'?'🎓 '+t('examD'):'📝 '+t('mockD')}</p>`}</div>`).join('')+
   (p.skipped.length?`<div class="card sm"><b>${t('skipped')}:</b> ${p.skipped.map(k=>LES(k.id).title[li()]).join(', ')}</div>`:'')+`<button class="btn" data-ai="apply" ${AI.applied?'disabled':''}>${AI.applied?'✅ '+t('applied'):'⏰ '+t('apply')}</button>`}
 else if(v==='map'){const R=118,cx=160,cy=165,pos={};LESSONS.forEach((l,i)=>{const a=-Math.PI/2+i*2*Math.PI/LESSONS.length;pos[l.id]=[cx+R*Math.cos(a),cy+R*Math.sin(a)]});
  const edges=LINKS.map(([a,b])=>`<line x1="${pos[a][0]}" y1="${pos[a][1]}" x2="${pos[b][0]}" y2="${pos[b][1]}" class="edge ${st[a].st==='weak'||st[b].st==='weak'?'wk':''}"/>`).join('');
  const nodes=LESSONS.map(l=>{const [x,y]=pos[l.id],s=st[l.id],C=2*Math.PI*27,p=s.p===null?(s.d?15:0):s.p;
   return`<g class="node" data-ai="node" data-id="${l.id}"><circle cx="${x}" cy="${y}" r="27" fill="none" stroke="#e6dcff" stroke-width="5"/><circle cx="${x}" cy="${y}" r="27" fill="none" stroke="${SC[s.st]}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C}" data-o="${C*(1-p/100)}" transform="rotate(-90 ${x} ${y})" class="arc"/><circle cx="${x}" cy="${y}" r="21" fill="${s.st==='todo'?'#fff':SC[s.st]}" opacity="${s.st==='todo'?.8:.9}"/><text x="${x}" y="${y+7}" text-anchor="middle" font-size="20">${l.icon}</text></g>`}).join('');
  h=head('🕸️ '+t('mapT'),1)+`<div class="card"><svg viewBox="0 0 320 330" class="mapsvg">${edges}<circle cx="${cx}" cy="${cy}" r="30" fill="#B79CFF"/><text x="${cx}" y="${cy+6}" text-anchor="middle" font-size="22">🙂</text>${nodes}</svg><div class="legend">${['strong','ok','weak','nw','todo'].map(k=>`<span><i style="background:${SC[k]}"></i>${t(k)}</span>`).join('')}</div></div><div id="mapInfo" class="card sm">👆</div>`;
  setTimeout(()=>$$('.arc').forEach(a=>a.style.strokeDashoffset=a.dataset.o),80)}
 box.innerHTML=h;
}
function nodeInfo(id){const l=LES(id),s=stats()[id],rel=LINKS.filter(x=>x.includes(id)).map(x=>LES(x[0]===id?x[1]:x[0]));
 const weakRel=rel.filter(r=>stats()[r.id].st==='weak');
 $('#mapInfo').innerHTML=`<b>${l.icon} ${l.title[li()]}</b><p>${t(s.st)}${s.p!==null?' · '+s.p+'%':''}</p>${bar(s.p===null?(s.d?15:0):s.p,SC[s.st])}<p class="sm">${t('rel')}: ${rel.map(r=>r.icon+' '+r.title[li()]).join(' · ')}</p>${weakRel.length?`<p class="sm">⚠️ ${t('revise')}: ${weakRel.map(r=>r.title[li()]).join(', ')}</p>`:''}<button class="fq" data-ai="learn" data-id="${id}">${s.d?'🔁 '+t('revise'):'▶ '+t('learn')}</button><button class="fq" data-ai="prac" data-id="${id}">🎯 ${t('prac')}</button>`}

document.addEventListener('click',e=>{
 const a=e.target.closest&&e.target.closest('#ai [data-ai],#ai [data-lv],#ai [data-h],#ai .ans');if(!a)return;
 if(a.classList.contains('ans')){const Q=AI.q;if(AI.sel!==null)return;const i=+a.dataset.a,c=Q.list[Q.i],ok=i===c.a;AI.sel=i;if(ok)Q.score++;
  AI.res.push({id:c.id,k:c.k,ok,at:Date.now(),q:c.q.slice(0,90)});aiSave();logEv('quiz',c.id);aiScreen();return}
 if(a.dataset.lv){AI.lv=a.dataset.lv==='auto'?'auto':+a.dataset.lv;return aiScreen()}
 if(a.dataset.h){AI.hrs=+a.dataset.h;return aiScreen()}
 const k=a.dataset.ai,id=a.dataset.id;
 if(k==='home')return go('home');
 if(k==='start'){const tp=$('#aiTopic');return startQuiz(tp?tp.value:AI.id,AI.lv)}
 if(k==='sayq')return sayQ();
 if(k==='nextq'){const Q=AI.q;AI.sel=null;Q.i++;if(Q.i>=Q.list.length)Q.done=true;return aiScreen()}
 if(k==='prac')return startQuiz(id,'auto');
 if(k==='learn')return openLesson(id);
 if(k==='node')return nodeInfo(id||a.closest('[data-id]').dataset.id);
 if(k==='mkplan'){const d=$('#rsDate');AI.date=d&&d.value||AI.date;AI.plan=rescue(AI.date,AI.hrs);AI.applied=0;return aiScreen()}
 if(k==='apply')return applyRescue();
 AI.view=k;if(k==='gen')AI.q=null;aiScreen()});
document.addEventListener('change',e=>{if(e.target.id==='aiTopic')AI.id=e.target.value});
