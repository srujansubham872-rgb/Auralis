/* HD step illustrations (inline SVG). Paint lesson is drawn step by step; others use a glowing orb scene. */
const PAL={paint:['#ffb3da','#b79cff'],boat:['#9fd4ff','#b79cff'],stretch:['#ffd2a8','#c9a8ff'],sing:['#ff9ccf','#9b7bff'],words:['#a8f0e0','#b79cff'],python:['#a8d8ff','#7b9cff'],history:['#ffd9a0','#c9a0ff'],stock:['#b8f0c8','#9b8cff'],done:['#ffe27a','#ff9ccf']};
function art(id,n,emo){
  const [a,b]=PAL[id]||PAL.paint;
  const defs=`<defs><linearGradient id="sk" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#efe6ff"/><stop offset="1" stop-color="#fff"/></linearGradient>
  <linearGradient id="pt" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9ccf"/><stop offset="1" stop-color="#b79cff"/></linearGradient>
  <radialGradient id="orb" cx="40%" cy="35%"><stop offset="0" stop-color="#fff"/><stop offset=".55" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></radialGradient>
  <filter id="bl"><feGaussianBlur stdDeviation="9"/></filter></defs>`;
  let dots='';for(let i=0;i<9;i++){const x=20+i*32,y=30+(i*53)%150;dots+=`<circle cx="${x}" cy="${y}" r="${3+i%3}" fill="${i%2?a:b}" opacity=".6"><animate attributeName="cy" values="${y};${y-16};${y}" dur="${3+i%4}s" repeatCount="indefinite"/></circle>`}
  let body;
  if(id==='paint'&&n>=0){
    const pet=[...Array(8)].map((_,i)=>`<ellipse cx="150" cy="62" rx="14" ry="25" transform="rotate(${i*45} 150 95)" fill="${n>=4?'url(#pt)':'none'}" stroke="#8f6bff" stroke-width="2.5" ${n>=4?'':'stroke-dasharray="5 4"'} class="dr"/>`).join('');
    body=`<ellipse cx="150" cy="198" rx="70" ry="9" fill="#b79cff" opacity=".25"/>
    ${n>=2?'<path d="M150 112 C138 150 164 172 150 200" stroke="#4caf7a" stroke-width="7" fill="none" stroke-linecap="round" class="dr"/>':''}
    ${n>=3?'<ellipse cx="128" cy="160" rx="20" ry="9" transform="rotate(-30 128 160)" fill="#6fd29a" class="dr"/><ellipse cx="172" cy="172" rx="20" ry="9" transform="rotate(30 172 172)" fill="#6fd29a" class="dr"/>':''}
    ${n>=1?pet:''}<circle cx="150" cy="95" r="17" fill="${n>=5?'#ffd23f':'none'}" stroke="#8f6bff" stroke-width="2.5" ${n>=5?'':'stroke-dasharray="5 4"'} class="dr"/>${n===0?'<text x="215" y="50" font-size="30">✏️</text>':''}`;
  }else{
    body=`<circle cx="150" cy="105" r="70" fill="${a}" opacity=".55" filter="url(#bl)"/>
    <ellipse cx="150" cy="105" rx="105" ry="30" fill="none" stroke="${b}" stroke-width="2" opacity=".5" transform="rotate(-18 150 105)"><animateTransform attributeName="transform" type="rotate" from="-18 150 105" to="342 150 105" dur="14s" repeatCount="indefinite"/></ellipse>
    <circle cx="150" cy="105" r="62" fill="url(#orb)"/><ellipse cx="130" cy="78" rx="22" ry="11" fill="#fff" opacity=".55"/>
    <text x="150" y="128" font-size="72" text-anchor="middle"><animateTransform attributeName="transform" type="translate" values="0 0;0 -7;0 0" dur="3s" repeatCount="indefinite"/>${emo}</text>`;
  }
  return `<svg viewBox="0 0 300 210" role="img">${defs}<rect width="300" height="210" rx="26" fill="url(#sk)"/>${dots}${body}</svg>`;
}
