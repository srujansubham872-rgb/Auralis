/* Growth Hub: progress tracking + analytics on the Progress screen.
   Data = S.ev (lesson / question / quiz events with timestamps, saved by exam.js) + S.done. Works offline; "sample data" previews a full report.
   Points: lesson 10, question 2 (same as the Growth Coach / backend). Weekly goal is stored per student in localStorage. */
Object.assign(T.en,{chTitle:'Progress & Analytics',chGoal:'Weekly goal',chPts:'points this week',chLeft:'{r} more points to reach your goal',chReached:'Goal reached! 🎉',chStreak:'Day streak',chActive:'Active days (14d)',chTotal:'Total points',chLessons:'Lessons done',
 chDaily:'Last 14 days',chHeat:'Activity (5 weeks)',chTime:'When you learn best',chBestDay:'Best day',chMorn:'Morning',chAft:'Afternoon',chEve:'Evening',chNight:'Night',chCourse:'Course progress',chMile:'Milestones',chInsight:'Coach insights',
 chTour:'Animated explanation',chTourSub:'Your 3D coach explains your numbers',chSample:'Preview with sample data',chEmpty:'Finish a lesson or ask a question and your analytics start here.',chRealBack:'Back to my data',
 mFirst:'First lesson',mS3:'3-day streak',mS7:'7-day streak',m100:'100 points',mAll:'All lessons',
 i1:'This week you earned {c} points, {d} than last week ({p}).',iMore:'more',iLess:'fewer',iSame:'the same as',i2:'You learn best in the {s}. Try to schedule your reminder then.',i3:'You were active on {d} of the last 14 days ({c}% consistency).',i4:'Your best day is {w}.',i5:'Next step: {a}.',i6:'You finished every lesson. Ask the chatbot for a new topic!',
 tClose:'Close',tPlay:'Play',tPause:'Pause',tNext:'Next',tPrev:'Back',tSound:'Voice',
 t1h:'How points work',t1:'Every lesson you finish gives 10 points and every question you ask gives 2. Points are how I measure your growth.',
 t2h:'Weekly growth',t2a:'This week you earned {c} points. Last week it was {p}. That is a {g}% change.',t2b:'This week you earned {c} points. Keep going and I will compare weeks for you.',
 t3h:'Your streak',t3:'You were active on {d} of the last 14 days and your current streak is {s} days. Small steps every day beat big steps once in a while.',
 t4h:'Weekly goal',t4:'Your weekly goal is {g} points. You are at {c}, that is {p}%. {x}',t4a:'Only {r} more points to go!',t4b:'Goal reached. Fantastic!',
 t5h:'Your next step',t5:'Next step: {a}. Finish one lesson today and watch your growth go up!',t5b:'You finished every lesson. Ask me a new topic to keep growing!'});
Object.assign(T.hi,{chTitle:'प्रगति और विश्लेषण',chGoal:'साप्ताहिक लक्ष्य',chPts:'अंक इस हफ़्ते',chLeft:'लक्ष्य तक {r} अंक और',chReached:'लक्ष्य पूरा! 🎉',chStreak:'दिन की लकीर',chActive:'सक्रिय दिन (14)',chTotal:'कुल अंक',chLessons:'पूरे पाठ',
 chDaily:'पिछले 14 दिन',chHeat:'गतिविधि (5 हफ़्ते)',chTime:'आप कब सबसे अच्छा सीखते हैं',chBestDay:'सबसे अच्छा दिन',chMorn:'सुबह',chAft:'दोपहर',chEve:'शाम',chNight:'रात',chCourse:'कोर्स प्रगति',chMile:'उपलब्धियाँ',chInsight:'कोच की सलाह',
 chTour:'एनिमेटेड समझाइश',chTourSub:'आपका 3D कोच आपके आँकड़े समझाता है',chSample:'नमूना डेटा से देखें',chEmpty:'एक पाठ पूरा कीजिए या सवाल पूछिए, विश्लेषण यहीं शुरू होगा।',chRealBack:'मेरे डेटा पर वापस',
 mFirst:'पहला पाठ',mS3:'3 दिन लगातार',mS7:'7 दिन लगातार',m100:'100 अंक',mAll:'सभी पाठ',
 i1:'इस हफ़्ते आपने {c} अंक कमाए, पिछले हफ़्ते ({p}) से {d}।',iMore:'ज़्यादा',iLess:'कम',iSame:'बराबर',i2:'आप {s} में सबसे अच्छा सीखते हैं। रिमाइंडर उसी समय रखिए।',i3:'पिछले 14 में से {d} दिन आप सक्रिय रहे ({c}% निरंतरता)।',i4:'आपका सबसे अच्छा दिन {w} है।',i5:'अगला कदम: {a}।',i6:'आपने सभी पाठ पूरे कर लिए। चैटबॉट से नया विषय पूछिए!',
 tClose:'बंद',tPlay:'चलाएँ',tPause:'रोकें',tNext:'आगे',tPrev:'पीछे',tSound:'आवाज़',
 t1h:'अंक कैसे मिलते हैं',t1:'हर पूरे पाठ के 10 अंक और हर सवाल के 2 अंक मिलते हैं। अंकों से ही मैं आपकी प्रगति नापता हूँ।',
 t2h:'साप्ताहिक प्रगति',t2a:'इस हफ़्ते आपने {c} अंक कमाए। पिछले हफ़्ते {p} थे। यानी {g}% का बदलाव।',t2b:'इस हफ़्ते आपने {c} अंक कमाए। लगे रहिए, मैं हफ़्तों की तुलना करूँगा।',
 t3h:'आपकी लकीर',t3:'पिछले 14 में से {d} दिन आप सक्रिय रहे और अभी {s} दिन की लकीर है। रोज़ छोटे कदम, कभी-कभी बड़े कदम से बेहतर हैं।',
 t4h:'साप्ताहिक लक्ष्य',t4:'आपका साप्ताहिक लक्ष्य {g} अंक है। आप {c} पर हैं, यानी {p}%। {x}',t4a:'बस {r} अंक और!',t4b:'लक्ष्य पूरा। शानदार!',
 t5h:'आपका अगला कदम',t5:'अगला कदम: {a}। आज एक पाठ पूरा कीजिए और प्रगति बढ़ते देखिए!',t5b:'आपने सभी पाठ पूरे कर लिए। बढ़ते रहने के लिए नया विषय पूछिए!'});
Object.assign(T.or,{chTitle:'ପ୍ରଗତି ଓ ବିଶ୍ଲେଷଣ',chGoal:'ସାପ୍ତାହିକ ଲକ୍ଷ୍ୟ',chPts:'ପଏଣ୍ଟ ଏହି ସପ୍ତାହ',chLeft:'ଲକ୍ଷ୍ୟ ପର୍ଯ୍ୟନ୍ତ ଆଉ {r} ପଏଣ୍ଟ',chReached:'ଲକ୍ଷ୍ୟ ପୂରଣ! 🎉',chStreak:'ଦିନ ଧାରା',chActive:'ସକ୍ରିୟ ଦିନ (14)',chTotal:'ମୋଟ ପଏଣ୍ଟ',chLessons:'ସମାପ୍ତ ପାଠ',
 chDaily:'ଗତ 14 ଦିନ',chHeat:'କାର୍ଯ୍ୟକଳାପ (5 ସପ୍ତାହ)',chTime:'ଆପଣ କେବେ ଭଲ ଶିଖନ୍ତି',chBestDay:'ସର୍ବୋତ୍ତମ ଦିନ',chMorn:'ସକାଳ',chAft:'ଅପରାହ୍ନ',chEve:'ସନ୍ଧ୍ୟା',chNight:'ରାତି',chCourse:'କୋର୍ସ ପ୍ରଗତି',chMile:'ମାଇଲଖୁଣ୍ଟ',chInsight:'କୋଚ୍ ପରାମର୍ଶ',
 chTour:'ଆନିମେଟେଡ୍ ବ୍ୟାଖ୍ୟା',chTourSub:'ଆପଣଙ୍କ 3D କୋଚ୍ ଆପଣଙ୍କ ସଂଖ୍ୟା ବୁଝାଏ',chSample:'ନମୁନା ଡାଟାରେ ଦେଖନ୍ତୁ',chEmpty:'ଗୋଟିଏ ପାଠ ସମାପ୍ତ କରନ୍ତୁ ବା ପ୍ରଶ୍ନ ପଚାରନ୍ତୁ, ବିଶ୍ଲେଷଣ ଏଠାରୁ ଆରମ୍ଭ ହେବ।',chRealBack:'ମୋ ଡାଟାକୁ ଫେରନ୍ତୁ',
 mFirst:'ପ୍ରଥମ ପାଠ',mS3:'3 ଦିନ ଲଗାତାର',mS7:'7 ଦିନ ଲଗାତାର',m100:'100 ପଏଣ୍ଟ',mAll:'ସବୁ ପାଠ',
 i1:'ଏହି ସପ୍ତାହ ଆପଣ {c} ପଏଣ୍ଟ ପାଇଲେ, ଗତ ସପ୍ତାହ ({p}) ଠାରୁ {d}।',iMore:'ଅଧିକ',iLess:'କମ୍',iSame:'ସମାନ',i2:'ଆପଣ {s} ରେ ସବୁଠାରୁ ଭଲ ଶିଖନ୍ତି। ସେହି ସମୟରେ ରିମାଇଣ୍ଡର୍ ରଖନ୍ତୁ।',i3:'ଗତ 14 ଦିନ ମଧ୍ୟରୁ {d} ଦିନ ଆପଣ ସକ୍ରିୟ ଥିଲେ ({c}% ନିରନ୍ତରତା)।',i4:'ଆପଣଙ୍କ ସର୍ବୋତ୍ତମ ଦିନ {w}।',i5:'ପରବର୍ତ୍ତୀ ପଦକ୍ଷେପ: {a}।',i6:'ଆପଣ ସବୁ ପାଠ ଶେଷ କଲେ। ଚାଟବଟ୍‌କୁ ନୂଆ ବିଷୟ ପଚାରନ୍ତୁ!',
 tClose:'ବନ୍ଦ',tPlay:'ଚଲାନ୍ତୁ',tPause:'ରୋକନ୍ତୁ',tNext:'ଆଗକୁ',tPrev:'ପଛକୁ',tSound:'ସ୍ୱର',
 t1h:'ପଏଣ୍ଟ କିପରି ମିଳେ',t1:'ପ୍ରତ୍ୟେକ ସମାପ୍ତ ପାଠ ପାଇଁ 10 ଓ ପ୍ରତ୍ୟେକ ପ୍ରଶ୍ନ ପାଇଁ 2 ପଏଣ୍ଟ ମିଳେ। ପଏଣ୍ଟରେ ମୁଁ ଆପଣଙ୍କ ପ୍ରଗତି ମାପେ।',
 t2h:'ସାପ୍ତାହିକ ପ୍ରଗତି',t2a:'ଏହି ସପ୍ତାହ ଆପଣ {c} ପଏଣ୍ଟ ପାଇଲେ। ଗତ ସପ୍ତାହ {p} ଥିଲା। ଅର୍ଥାତ୍ {g}% ପରିବର୍ତ୍ତନ।',t2b:'ଏହି ସପ୍ତାହ ଆପଣ {c} ପଏଣ୍ଟ ପାଇଲେ। ଚାଲିଥାଆନ୍ତୁ, ମୁଁ ସପ୍ତାହ ତୁଳନା କରିବି।',
 t3h:'ଆପଣଙ୍କ ଧାରା',t3:'ଗତ 14 ଦିନ ମଧ୍ୟରୁ {d} ଦିନ ଆପଣ ସକ୍ରିୟ ଥିଲେ ଓ ବର୍ତ୍ତମାନ {s} ଦିନର ଧାରା। ପ୍ରତିଦିନ ଛୋଟ ପଦକ୍ଷେପ, କେବେ କେବେ ବଡ଼ ପଦକ୍ଷେପଠାରୁ ଭଲ।',
 t4h:'ସାପ୍ତାହିକ ଲକ୍ଷ୍ୟ',t4:'ଆପଣଙ୍କ ସାପ୍ତାହିକ ଲକ୍ଷ୍ୟ {g} ପଏଣ୍ଟ। ଆପଣ {c} ରେ, ଅର୍ଥାତ୍ {p}%। {x}',t4a:'ମାତ୍ର {r} ପଏଣ୍ଟ ଆଉ!',t4b:'ଲକ୍ଷ୍ୟ ପୂରଣ। ବହୁତ ବଢ଼ିଆ!',
 t5h:'ଆପଣଙ୍କ ପରବର୍ତ୍ତୀ ପଦକ୍ଷେପ',t5:'ପରବର୍ତ୍ତୀ ପଦକ୍ଷେପ: {a}। ଆଜି ଗୋଟିଏ ପାଠ ଶେଷ କରନ୍ତୁ ଓ ପ୍ରଗତି ବଢ଼ିବା ଦେଖନ୍ତୁ!',t5b:'ଆପଣ ସବୁ ପାଠ ଶେଷ କଲେ। ବଢ଼ିବା ପାଇଁ ନୂଆ ବିଷୟ ପଚାରନ୍ତୁ!'});
Object.assign(T.ur,{chTitle:'پیش رفت اور تجزیہ',chGoal:'ہفتہ وار ہدف',chPts:'پوائنٹس اس ہفتے',chLeft:'ہدف تک {r} پوائنٹس اور',chReached:'ہدف پورا! 🎉',chStreak:'دنوں کا سلسلہ',chActive:'فعال دن (14)',chTotal:'کل پوائنٹس',chLessons:'مکمل اسباق',
 chDaily:'پچھلے 14 دن',chHeat:'سرگرمی (5 ہفتے)',chTime:'آپ کب بہتر سیکھتے ہیں',chBestDay:'بہترین دن',chMorn:'صبح',chAft:'دوپہر',chEve:'شام',chNight:'رات',chCourse:'کورس کی پیش رفت',chMile:'سنگ میل',chInsight:'کوچ کی رائے',
 chTour:'اینیمیٹڈ وضاحت',chTourSub:'آپ کا 3D کوچ آپ کے اعداد سمجھاتا ہے',chSample:'نمونہ ڈیٹا سے دیکھیں',chEmpty:'ایک سبق مکمل کریں یا سوال پوچھیں، تجزیہ یہیں سے شروع ہوگا۔',chRealBack:'میرے ڈیٹا پر واپس',
 mFirst:'پہلا سبق',mS3:'3 دن مسلسل',mS7:'7 دن مسلسل',m100:'100 پوائنٹس',mAll:'تمام اسباق',
 i1:'اس ہفتے آپ نے {c} پوائنٹس کمائے، پچھلے ہفتے ({p}) سے {d}۔',iMore:'زیادہ',iLess:'کم',iSame:'برابر',i2:'آپ {s} میں بہترین سیکھتے ہیں۔ ریمائنڈر اسی وقت رکھیں۔',i3:'پچھلے 14 میں سے {d} دن آپ فعال رہے ({c}% تسلسل)۔',i4:'آپ کا بہترین دن {w} ہے۔',i5:'اگلا قدم: {a}۔',i6:'آپ نے تمام اسباق مکمل کر لیے۔ چیٹ بوٹ سے نیا موضوع پوچھیں!',
 tClose:'بند',tPlay:'چلائیں',tPause:'روکیں',tNext:'آگے',tPrev:'پیچھے',tSound:'آواز',
 t1h:'پوائنٹس کیسے ملتے ہیں',t1:'ہر مکمل سبق کے 10 اور ہر سوال کے 2 پوائنٹس ملتے ہیں۔ پوائنٹس سے میں آپ کی ترقی ناپتا ہوں۔',
 t2h:'ہفتہ وار ترقی',t2a:'اس ہفتے آپ نے {c} پوائنٹس کمائے۔ پچھلے ہفتے {p} تھے۔ یعنی {g}% تبدیلی۔',t2b:'اس ہفتے آپ نے {c} پوائنٹس کمائے۔ لگے رہیں، میں ہفتوں کا موازنہ کروں گا۔',
 t3h:'آپ کا سلسلہ',t3:'پچھلے 14 میں سے {d} دن آپ فعال رہے اور اب {s} دن کا سلسلہ ہے۔ روز چھوٹے قدم، کبھی کبھار بڑے قدم سے بہتر ہیں۔',
 t4h:'ہفتہ وار ہدف',t4:'آپ کا ہفتہ وار ہدف {g} پوائنٹس ہے۔ آپ {c} پر ہیں، یعنی {p}%۔ {x}',t4a:'بس {r} پوائنٹس اور!',t4b:'ہدف پورا۔ شاندار!',
 t5h:'آپ کا اگلا قدم',t5:'اگلا قدم: {a}۔ آج ایک سبق مکمل کریں اور ترقی بڑھتی دیکھیں!',t5b:'آپ نے تمام اسباق مکمل کر لیے۔ بڑھتے رہنے کے لیے نیا موضوع پوچھیں!'});

const CH={demo:false,PTS:{lesson:10,question:2}};
const _dk=d=>{const x=new Date(d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')};
const _day0=d=>{const x=new Date(d);x.setHours(0,0,0,0);return x};
const goalKey=()=>'auralis_goal_'+(S.user.contact||'guest');
const getGoal=()=>{try{return Math.max(10,+localStorage.getItem(goalKey())||40)}catch{return 40}};
const setGoal=v=>{try{localStorage.setItem(goalKey(),String(v))}catch{}};
const cfmt=(s,o)=>s.replace(/\{(\w+)\}/g,(_,k)=>o[k]);

/* deterministic sample events: ~5 weeks, growing activity, mostly evenings */
function sampleEvents(){
  const out=[],now=Date.now(),plan=[0,0,1,0,2,0,1, 1,0,2,1,0,3,0, 1,2,0,2,1,2,1, 2,1,2,0,3,2,1, 2,3,1,3,2,3,4];
  plan.forEach((n,i)=>{const day=_day0(now-(34-i)*864e5);
    for(let j=0;j<Math.ceil(n/2);j++){const h=[19,20,8,21,13][(i+j)%5];out.push({k:'lesson',id:'x',at:day.getTime()+h*36e5+j*6e5});
      for(let q=0;q<1+(i%2);q++)out.push({k:'question',at:day.getTime()+h*36e5+(j*3+q+2)*6e4})}});
  return out}

function coachMetrics(demo){
  const ev=demo?sampleEvents():S.ev;if(!ev.length&&!demo)return null;
  const today=_day0(Date.now()),pts=e=>CH.PTS[e.k]||0,by={};
  ev.forEach(e=>{const k=_dk(e.at),d=by[k]||(by[k]={pts:0,les:0,q:0,n:0});d.pts+=pts(e);d.n++;if(e.k==='lesson')d.les++;if(e.k==='question')d.q++});
  const day=i=>{const dt=new Date(today.getTime()-i*864e5),d=by[_dk(dt)]||{pts:0,les:0,q:0,n:0};return{date:dt,...d}};
  const daily=[...Array(14)].map((_,i)=>day(13-i));
  const mon=(today.getDay()+6)%7;
  /* heat grid: 5 columns (weeks) x 7 rows (Mon..Sun), the last column ends today */
  const grid=[];for(let w=0;w<5;w++)for(let d=0;d<7;d++){const off=(4-w)*7+(mon-d);grid.push(off<0?null:day(off))}
  const thisWeek=[...Array(mon+1)].reduce((a,_,i)=>a+day(i).pts,0);
  const lastWeek=[...Array(7)].reduce((a,_,i)=>a+day(mon+1+i).pts,0);
  /* weekly series (last 6 weeks, oldest first) */
  const weeks=[...Array(6)].map((_,k)=>{const n=5-k;let s=0;const len=n===0?mon+1:7,start=n===0?0:mon+1+(n-1)*7;for(let i=0;i<len;i++)s+=day(start+i).pts;return{points:s,label:_dk(new Date(today.getTime()-(start+len-1)*864e5)).slice(5)}});
  let streak=0,i0=day(0).n?0:1;for(let i=i0;i<400&&day(i).n;i++)streak++;
  let best=0,run=0;for(let i=0;i<35;i++){if(day(34-i).n){run++;best=Math.max(best,run)}else run=0}
  const active14=daily.filter(d=>d.n).length,total=ev.reduce((a,e)=>a+pts(e),0);
  const slots=[0,0,0,0],wd=[0,0,0,0,0,0,0];
  ev.forEach(e=>{const h=new Date(e.at).getHours();slots[h>=5&&h<12?0:h>=12&&h<17?1:h>=17&&h<22?2:3]+=Math.max(pts(e),1);wd[(new Date(e.at).getDay()+6)%7]+=Math.max(pts(e),1)});
  const bestSlot=slots.indexOf(Math.max(...slots)),bestWd=wd.indexOf(Math.max(...wd));
  const done=demo?3:S.done.size;
  const goal=getGoal();
  const ms=[['🌱','mFirst',done>=1||total>=10],['🔥','mS3',best>=3],['⚡','mS7',best>=7],['⭐','m100',total>=100],['👑','mAll',!demo&&courseDone()]];
  const nx=LESSONS.find(l=>demo?!['paint','boat','python'].includes(l.id):!S.done.has(l.id));
  return{daily,grid,weeks,thisWeek,lastWeek,streak,best,active14,consistency:Math.round(active14/14*100),total,slots,bestSlot,wd,bestWd,done,goal,
   goalPct:Math.min(100,Math.round(thisWeek/goal*100)),growth:lastWeek>0?Math.round((thisWeek-lastWeek)/lastWeek*1000)/10:0,ms,next:nx||null,demo}}

const SLOT_K=['chMorn','chAft','chEve','chNight'];
const wdName=i=>{const d=new Date(2024,0,1+i);try{return d.toLocaleDateString(SPEECH[S.lang]||'en',{weekday:'long'})}catch{return d.toLocaleDateString('en',{weekday:'long'})}};
const shortWd=d=>{try{return d.toLocaleDateString(SPEECH[S.lang]||'en',{weekday:'narrow'})}catch{return d.toLocaleDateString('en',{weekday:'narrow'})}};

function coachInsights(m){
  const out=[];
  out.push(cfmt(t('i1'),{c:m.thisWeek,p:m.lastWeek,d:t(m.thisWeek>m.lastWeek?'iMore':m.thisWeek<m.lastWeek?'iLess':'iSame')}));
  out.push(cfmt(t('i2'),{s:t(SLOT_K[m.bestSlot]).toLowerCase()}));
  out.push(cfmt(t('i3'),{d:m.active14,c:m.consistency}));
  out.push(cfmt(t('i4'),{w:wdName(m.bestWd)}));
  out.push(m.next?cfmt(t('i5'),{a:m.next.title[li()]}):t('i6'));
  return out}

/* ---------- rendering ---------- */
function ringSvg(pct){const r=38,c=2*Math.PI*r;return`<svg width="92" height="92" viewBox="0 0 90 90"><defs><linearGradient id="chg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffb86b"/><stop offset="1" stop-color="#8f6bff"/></linearGradient></defs><circle cx="45" cy="45" r="${r}" fill="none" stroke="#e7defc" stroke-width="9"/><circle class="chring" cx="45" cy="45" r="${r}" fill="none" stroke="url(#chg)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c*(1-pct/100)}" transform="rotate(-90 45 45)" style="--c:${c}"/><text x="45" y="50" text-anchor="middle" font-weight="800" font-size="17" fill="#3B2A6B">${pct}%</text></svg>`}
function trendSvg(d){const W=300,H=110,P=10,mx=Math.max(...d.map(x=>x.pts),10),X=i=>P+i*(W-2*P)/(d.length-1),Y=v=>H-18-(v/mx)*(H-34);
  const pts=d.map((x,i)=>[X(i),Y(x.pts)]),line=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' '),area=line+` L${X(d.length-1)} ${H-18} L${X(0)} ${H-18} Z`;
  const lab=[0,6,13].map(i=>`<text x="${X(i)}" y="${H-3}" text-anchor="${i===0?'start':i===13?'end':'middle'}" font-size="9" fill="#8a7bb8">${d[i].date.getDate()}/${d[i].date.getMonth()+1}</text>`).join('');
  return`<svg viewBox="0 0 ${W} ${H}" class="chtrend" role="img" aria-label="${t('chDaily')}"><defs><linearGradient id="cha" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8f6bff" stop-opacity=".45"/><stop offset="1" stop-color="#8f6bff" stop-opacity="0"/></linearGradient></defs>
  <path d="${area}" fill="url(#cha)" class="charea"/><path d="${line}" fill="none" stroke="#8f6bff" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" pathLength="1" class="chline"/>
  ${pts.map((p,i)=>d[i].pts?`<circle cx="${p[0]}" cy="${p[1]}" r="3.2" fill="#fff" stroke="#ff7ac8" stroke-width="2"><title>${d[i].date.getDate()}/${d[i].date.getMonth()+1}: ${d[i].pts}</title></circle>`:'').join('')}${lab}</svg>`}

function coachHub(){
  const box=document.getElementById('hub');if(!box)return;
  let m=coachMetrics(CH.demo);
  if(!m){box.innerHTML=`<div class="card hub"><b>📈 ${t('chTitle')}</b><p class="sm" style="margin:8px 0">${t('chEmpty')}</p><button class="btn small" id="hSample">${t('chSample')}</button></div>`;
    document.getElementById('hSample').onclick=()=>{CH.demo=true;coachHub()};return}
  const mxS=Math.max(...m.slots,1),left=Math.max(0,m.goal-m.thisWeek);
  box.innerHTML=`<div class="card hub">
   <div class="hubh"><b>📈 ${t('chTitle')}</b>${m.demo?`<button class="btn ghost small" id="hBack">${t('chRealBack')}</button>`:''}</div>
   <div class="hgoal">${ringSvg(m.goalPct)}<div><b>${t('chGoal')}: ${m.goal}</b><p class="sm">${m.thisWeek} ${t('chPts')}</p><p class="sm hl">${left?cfmt(t('chLeft'),{r:left}):t('chReached')}</p>
     <div class="hstep"><button id="gMinus" aria-label="-10">−</button><span>10</span><button id="gPlus" aria-label="+10">+</button></div></div></div>
   <div class="hkpi"><div><b>🔥 ${m.streak}</b><small>${t('chStreak')}</small></div><div><b>⚡ ${m.active14}/14</b><small>${t('chActive')}</small></div><div><b>⭐ ${m.total}</b><small>${t('chTotal')}</small></div><div><b>🎓 ${m.done}/${LESSONS.length}</b><small>${t('chLessons')}</small></div></div>
   <h4>${t('chDaily')}</h4>${trendSvg(m.daily)}
   <h4>${t('chHeat')}</h4><div class="hheat">${m.grid.map(c=>`<i class="${!c?'x':c.pts>=20?'h3':c.pts>=8?'h2':c.n?'h1':''}" title="${c?_dk(c.date)+': '+c.pts:''}"></i>`).join('')}</div>
   <h4>${t('chTime')}</h4><div class="hslots">${m.slots.map((v,i)=>`<div class="${i===m.bestSlot&&v?'best':''}"><i style="--h:${v/mxS*100}%"></i><small>${t(SLOT_K[i])}</small></div>`).join('')}</div>
   <h4>${t('chCourse')}</h4><div class="hcourse">${LESSONS.map(l=>{const d=m.demo?['paint','boat','python'].includes(l.id):S.done.has(l.id);return`<span class="${d?'on':''}" title="${esc(l.title[li()])}">${l.icon}${d?'<em>✓</em>':''}</span>`}).join('')}</div>
   <h4>${t('chMile')}</h4><div class="hmile">${m.ms.map(x=>`<span class="${x[2]?'on':''}"><b>${x[0]}</b><small>${t(x[1])}</small></span>`).join('')}</div>
   <h4>🤖 ${t('chInsight')}</h4><ul class="hins">${coachInsights(m).map(s=>`<li>${esc(s)}</li>`).join('')}</ul>
   <button class="btn" id="hTour">🧊 ${t('chTour')}<small class="hsub">${t('chTourSub')}</small></button></div>`;
  const b=document.getElementById('hBack');if(b)b.onclick=()=>{CH.demo=false;coachHub()};
  document.getElementById('gMinus').onclick=()=>{setGoal(Math.max(10,m.goal-10));coachHub()};
  document.getElementById('gPlus').onclick=()=>{setGoal(m.goal+10);coachHub()};
  document.getElementById('hTour').onclick=()=>window.coachTour&&coachTour(m);
}
