/* Extras: floating-layers "A" logo, home-screen robot guide, 3 subscription plans (+ their translations). */
Object.assign(T.en,{plans:'Plans',per3:'for 3 months',choose:'Choose plan',popular:'Most popular',subbed:'Subscribed',pBasic:'Basic',pMedium:'Medium',pPremium:'Premium',f1:'All lessons',f2:'Daily reminders',f3:'Chatbot: 10 questions a day',f4:'Unlimited chatbot',f5:'Voice, image & video help',f6:'Offline downloads',robotT:'What can Auralis do?',r1:'I teach you any activity step by step.',r2:'I set reminders so you never miss practice.',r3:'Ask me by text, voice or photo.',r4:'I fix your grammar in any language.',banner:'See plans from ₹199'});
Object.assign(T.hi,{plans:'प्लान',per3:'3 महीने के लिए',choose:'प्लान चुनें',popular:'सबसे लोकप्रिय',subbed:'सब्सक्राइब किया',pBasic:'बेसिक',pMedium:'मीडियम',pPremium:'प्रीमियम',f1:'सभी पाठ',f2:'रोज़ रिमाइंडर',f3:'चैटबॉट: रोज़ 10 सवाल',f4:'असीमित चैटबॉट',f5:'आवाज़, फ़ोटो और वीडियो मदद',f6:'ऑफ़लाइन डाउनलोड',robotT:'ऑरालिस क्या कर सकता है?',r1:'मैं कोई भी गतिविधि चरण दर चरण सिखाता हूँ।',r2:'मैं रिमाइंडर लगाता हूँ ताकि अभ्यास न छूटे।',r3:'मुझसे लिखकर, बोलकर या फ़ोटो से पूछिए।',r4:'मैं किसी भी भाषा का व्याकरण सुधारता हूँ।',banner:'₹199 से प्लान देखें'});
Object.assign(T.or,{plans:'ପ୍ଲାନ୍',per3:'3 ମାସ ପାଇଁ',choose:'ପ୍ଲାନ୍ ବାଛନ୍ତୁ',popular:'ସବୁଠାରୁ ଲୋକପ୍ରିୟ',subbed:'ସବ୍‌ସ୍କ୍ରାଇବ୍ ହେଲା',pBasic:'ବେସିକ୍',pMedium:'ମିଡିୟମ୍',pPremium:'ପ୍ରିମିୟମ୍',f1:'ସମସ୍ତ ପାଠ',f2:'ପ୍ରତିଦିନ ସ୍ମାରକ',f3:'ଚାଟବଟ୍: ଦିନକୁ 10 ପ୍ରଶ୍ନ',f4:'ଅସୀମିତ ଚାଟବଟ୍',f5:'ସ୍ୱର, ଫଟୋ ଓ ଭିଡିଓ ସହାୟତା',f6:'ଅଫଲାଇନ୍ ଡାଉନଲୋଡ୍',robotT:'ଔରାଲିସ୍ କ’ଣ କରିପାରେ?',r1:'ମୁଁ ଯେକୌଣସି କାମ ପଦକ୍ଷେପ ପଦକ୍ଷେପ ଶିଖାଏ।',r2:'ମୁଁ ସ୍ମାରକ ଲଗାଏ, ଯାହାଫଳରେ ଅଭ୍ୟାସ ଛୁଟିବ ନାହିଁ।',r3:'ମୋତେ ଲେଖି, କହି ବା ଫଟୋରେ ପଚାରନ୍ତୁ।',r4:'ମୁଁ ଯେକୌଣସି ଭାଷାର ବ୍ୟାକରଣ ସୁଧାରେ।',banner:'₹199 ରୁ ପ୍ଲାନ୍ ଦେଖନ୍ତୁ'});
Object.assign(T.ur,{plans:'پلانز',per3:'3 ماہ کے لیے',choose:'پلان چنیں',popular:'سب سے مقبول',subbed:'سبسکرائب ہو گیا',pBasic:'بیسک',pMedium:'میڈیم',pPremium:'پریمیم',f1:'تمام اسباق',f2:'روزانہ یاد دہانی',f3:'چیٹ بوٹ: روزانہ 10 سوال',f4:'لامحدود چیٹ بوٹ',f5:'آواز، تصویر اور ویڈیو مدد',f6:'آف لائن ڈاؤن لوڈ',robotT:'اورالس کیا کر سکتا ہے؟',r1:'میں کوئی بھی سرگرمی قدم بہ قدم سکھاتا ہوں۔',r2:'میں یاد دہانی لگاتا ہوں تاکہ مشق نہ چھوٹے۔',r3:'مجھ سے لکھ کر، بول کر یا تصویر سے پوچھیں۔',r4:'میں کسی بھی زبان کی گرامر درست کرتا ہوں۔',banner:'₹199 سے پلانز دیکھیں'});

/* Logo: three floating layers forming the letter A */
function logoSVG(w){const A='M60 6L104 92H84L60 42L36 92H16Z';
return `<svg class="alogo" width="${w}" height="${w}" viewBox="0 0 120 120"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9ccf"/><stop offset="1" stop-color="#7a52f0"/></linearGradient></defs>
<ellipse class="lsh" cx="60" cy="114" rx="30" ry="5" fill="#7a52f0" opacity=".25"/>
<g transform="translate(0,18)"><g class="L L1"><path d="${A}" fill="#b79cff" opacity=".5"/></g></g>
<g transform="translate(0,9)"><g class="L L2"><path d="${A}" fill="#8f6bff" opacity=".8"/></g></g>
<g class="L L3"><path d="${A}" fill="url(#lg)"/><path d="M44 70h32v9H44z" fill="#fff" opacity=".85"/></g></svg>`}
document.getElementById('logoS').innerHTML=logoSVG(100);

/* Robot guide on the home screen */
document.getElementById('robotSvg').innerHTML=`<svg width="86" height="100" viewBox="0 0 120 140" class="bot"><defs><linearGradient id="bg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c4adff"/><stop offset="1" stop-color="#7a52f0"/></linearGradient></defs>
<line x1="60" y1="8" x2="60" y2="24" stroke="#7a52f0" stroke-width="4"/><circle class="ant" cx="60" cy="8" r="6" fill="#ff7ac8"/>
<rect x="24" y="24" width="72" height="56" rx="22" fill="url(#bg2)"/><rect x="33" y="36" width="54" height="30" rx="14" fill="#2b1a5c"/>
<circle class="eye" cx="48" cy="51" r="6" fill="#9ff3ff"/><circle class="eye" cx="72" cy="51" r="6" fill="#9ff3ff"/><path d="M52 60q8 6 16 0" stroke="#9ff3ff" stroke-width="2.5" fill="none" stroke-linecap="round"/>
<rect x="34" y="86" width="52" height="40" rx="16" fill="url(#bg2)"/><circle cx="60" cy="106" r="7" fill="#fff" opacity=".85"/>
<rect x="12" y="90" width="22" height="9" rx="4.5" fill="#8f6bff" transform="rotate(25 32 94)"/><g class="wave"><rect x="86" y="90" width="22" height="9" rx="4.5" fill="#8f6bff" transform="rotate(-35 88 94)"/></g></svg>`;
let _rt=null,_ri=0;
function robotStart(){const b=document.getElementById('bubble'),show=()=>{b.classList.remove('in');void b.offsetWidth;b.textContent=t('r'+(_ri%4+1));b.classList.add('in')};
  show();clearInterval(_rt);_rt=setInterval(()=>{if(S.cur!=='home')return;_ri++;show()},4200)}

/* Subscription plans: 3 months each */
const PLANS=[{id:'basic',price:199,k:'pBasic',f:['f1','f2','f3']},{id:'medium',price:299,k:'pMedium',f:['f1','f2','f4','f5'],pop:1},{id:'premium',price:399,k:'pPremium',f:['f1','f2','f4','f5','f6']}];
function plans(){const box=document.getElementById('planList');
  box.innerHTML=PLANS.map((p,i)=>`<div class="plan ${p.pop?'pop':''} ${S.plan===p.id?'on':''}" style="--i:${i}">${p.pop?`<span class="ribbon">${t('popular')}</span>`:''}<h3>${t(p.k)}</h3><div class="price">₹${p.price}</div><p class="sm">${t('per3')}</p><ul>${p.f.map(k=>`<li>${t(k)}</li>`).join('')}</ul><button class="btn" data-p="${p.id}">${S.plan===p.id?'✓ '+t('subbed'):t('choose')}</button></div>`).join('');
  box.querySelectorAll('button').forEach(b=>b.onclick=()=>{S.plan=b.dataset.p;DB.save({plan:S.plan});confetti();plans()})}
