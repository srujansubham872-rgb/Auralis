/* Growth Coach 3D answer (Three.js r128). Tap the Growth Coach card -> a full-screen 3D scene opens:
   a talking 3D robot coach, weekly points as rising 3D bars, a trend arrow, sparkles, and the coach's answer typed out (and speakable).
   Drag to rotate the bars. Works with backend data or with local data. */
function growth3D(g){
  const app=document.getElementById('app'),s=g.stats,full=g.message+' '+g.tip;
  const ov=document.createElement('div');ov.id='g3d';
  ov.innerHTML=`<canvas></canvas><button class="gclose" aria-label="close">✕</button>
   <div class="gpanel"><div class="gh"><b>🤖 ${t('gcTitle')}</b><span class="big ${s.trend==='down'?'dn':'up'}" style="font-size:1.6rem">${s.trend==='up'?'▲':s.trend==='down'?'▼':'▬'} ${s.avg_growth_pct>0?'+':''}${s.avg_growth_pct}%</span></div>
   <p class="gtxt"></p><p class="gmeta">${s.avg_points} ${t('gcPts')} · ${s.avg_lessons} ${t('gcLes')} · 🏆 ${s.best_week} · 🔥 ${s.streak_weeks}${g.demo?' · demo':''}</p>
   <div><button class="fq" id="g3say">🔊 ${t('gcSound')}</button><button class="fq" id="g3again">↻ ${t('gcAgain')}</button></div></div>`;
  app.append(ov);
  const cv=ov.querySelector('canvas'),txt=ov.querySelector('.gtxt');
  let talking=false,raf=0,typeTimer=0,disposed=false,R=null;

  /* ---- typed answer ---- */
  const chars=(()=>{try{return[...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(full)].map(x=>x.segment)}catch{return Array.from(full)}})();
  function type(){clearInterval(typeTimer);txt.textContent='';txt.classList.remove('done');let i=0;talking=true;
    typeTimer=setInterval(()=>{txt.textContent+=chars[i++];if(i>=chars.length){clearInterval(typeTimer);txt.classList.add('done');talking=false}},32)}
  function say(){if(!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(full);u.lang=SPEECH[S.lang];
    u.onstart=()=>talking=true;u.onend=u.onerror=()=>{if(txt.classList.contains('done'))talking=false};speechSynthesis.speak(u)}
  function close(){if(disposed)return;disposed=true;cancelAnimationFrame(raf);clearInterval(typeTimer);window.speechSynthesis&&speechSynthesis.cancel();
    document.removeEventListener('keydown',onKey);try{R&&R.dispose()}catch{}ov.remove()}
  const onKey=e=>{if(e.key==='Escape')close()};document.addEventListener('keydown',onKey);
  ov.querySelector('.gclose').onclick=close;ov.querySelector('#g3say').onclick=say;ov.querySelector('#g3again').onclick=()=>{speechSynthesis&&speechSynthesis.cancel();replay()};
  type();

  /* ---- 3D scene ---- */
  if(!window.THREE){return}
  try{R=new THREE.WebGLRenderer({canvas:cv,alpha:true,antialias:true})}catch{return}     // no WebGL -> the typed answer still shows
  R.setPixelRatio(Math.min(devicePixelRatio,2));
  const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(45,1,.1,100);cam.position.set(0,3.2,11.5);
  const resize=()=>{const w=cv.clientWidth||ov.clientWidth,h=cv.clientHeight||ov.clientHeight*.56;R.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();
    cam.position.z=Math.max(10.5,4.4/(Math.tan(Math.PI/8)*cam.aspect));};
  resize();addEventListener('resize',resize);
  sc.add(new THREE.AmbientLight(0xcbb8ff,.9));
  const l1=new THREE.PointLight(0xffffff,1.6,40);l1.position.set(4,8,8);const l2=new THREE.PointLight(0xff7ac8,1.4,40);l2.position.set(-6,3,6);sc.add(l1,l2);
  const lookY=2.6;

  /* text sprite helper */
  function label(str,size,color,w=256,h=128){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.font=`800 ${size}px Nunito,Poppins,sans-serif`;x.textAlign='center';x.textBaseline='middle';
    x.fillStyle=color;x.shadowColor='rgba(0,0,0,.35)';x.shadowBlur=8;x.fillText(str,w/2,h/2);const tx=new THREE.CanvasTexture(c);
    const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tx,transparent:true,depthTest:false}));sp.userData.aspect=w/h;return sp}

  /* platform + bars */
  const root=new THREE.Group();sc.add(root);
  const plat=new THREE.Mesh(new THREE.CylinderGeometry(4.0,4.0,.18,64),new THREE.MeshStandardMaterial({color:0xb79cff,metalness:.3,roughness:.4,transparent:true,opacity:.55}));plat.position.y=-.1;root.add(plat);
  const grid=new THREE.GridHelper(7.2,8,0xffffff,0xd8c8ff);grid.position.y=.01;grid.material.transparent=true;grid.material.opacity=.25;root.add(grid);
  const W=s.weeks,n=W.length,mx=Math.max(...W.map(w=>w.points),1),step=Math.min(.8,6.4/n),bw=step*.68,MAXH=2.9;
  const cLow=new THREE.Color(0xff9ccf),cHigh=new THREE.Color(0x8f6bff);
  const bars=W.map((w,i)=>{
    const geo=new THREE.BoxGeometry(bw,1,bw);geo.translate(0,.5,0);
    const col=cLow.clone().lerp(cHigh,w.points/mx),last=i===n-1;
    const m=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:col,metalness:.35,roughness:.25,emissive:last?0x5a2fd0:0x000000,emissiveIntensity:last?.55:0}));
    m.position.x=(i-(n-1)/2)*step;m.scale.y=.001;root.add(m);
    const h=Math.max(.12,w.points/mx*MAXH);
    const v=label(String(w.points),84,'#ffffff');v.scale.set(1.1,.55,1);v.position.set(m.position.x,.0,0);v.visible=false;root.add(v);
    const d=label(w.week,70,'#e9ddff');d.scale.set(step*1.25,step*.62,1);d.position.set(m.position.x,-.42,bw*.9);root.add(d);
    return{m,h,v,delay:i*.12}});

  /* trend arrow above the last bar */
  const up=s.trend==='up',flat=s.trend==='flat';
  const arrow=new THREE.Group();
  const aMat=new THREE.MeshStandardMaterial({color:flat?0xffd23f:up?0x6fe3a8:0xff6b9e,emissive:flat?0x6a5000:up?0x0a6a3e:0x7a1040,emissiveIntensity:.6,metalness:.3,roughness:.3});
  if(flat){arrow.add(new THREE.Mesh(new THREE.BoxGeometry(.9,.22,.22),aMat))}
  else{const head=new THREE.Mesh(new THREE.ConeGeometry(.38,.6,24),aMat),stem=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,.7,16),aMat);head.position.y=.55;stem.position.y=-.05;arrow.add(head,stem);if(!up)arrow.rotation.z=Math.PI}
  root.add(arrow);

  /* the 3D coach robot */
  const bot=new THREE.Group();sc.add(bot);bot.position.set(-2.3,5.0,1.2);bot.scale.setScalar(.95);
  const mP=c=>new THREE.MeshStandardMaterial({color:c,metalness:.35,roughness:.28});
  const head=new THREE.Mesh(new THREE.SphereGeometry(.85,40,28),mP(0xc4adff));head.scale.set(1.05,.88,.92);bot.add(head);
  const visor=new THREE.Mesh(new THREE.SphereGeometry(.64,32,24),new THREE.MeshStandardMaterial({color:0x2b1a5c,metalness:.6,roughness:.15}));visor.scale.set(1.12,.66,.5);visor.position.set(0,.02,.55);bot.add(visor);
  const eyeM=new THREE.MeshBasicMaterial({color:0x9ff3ff}),eyes=[-.27,.27].map(x=>{const e=new THREE.Mesh(new THREE.SphereGeometry(.1,16,12),eyeM);e.position.set(x,.1,.8);bot.add(e);return e});
  const mouth=new THREE.Mesh(new THREE.SphereGeometry(.08,16,12),eyeM);mouth.scale.set(1.8,.35,.5);mouth.position.set(0,-.14,.82);bot.add(mouth);
  const ant=new THREE.Mesh(new THREE.CylinderGeometry(.03,.03,.4,8),mP(0x8f6bff));ant.position.y=.95;bot.add(ant);
  const bulb=new THREE.Mesh(new THREE.SphereGeometry(.11,16,12),new THREE.MeshBasicMaterial({color:0xff7ac8}));bulb.position.y=1.2;bot.add(bulb);
  [-1,1].forEach(x=>{const ear=new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,.14,20),mP(0x8f6bff));ear.rotation.z=Math.PI/2;ear.position.set(x*.92,0,0);bot.add(ear)});
  const body=new THREE.Mesh(new THREE.SphereGeometry(.6,32,24),mP(0x8f6bff));body.scale.set(1,1.1,.85);body.position.y=-1.25;bot.add(body);
  const chest=new THREE.Mesh(new THREE.CircleGeometry(.17,24),new THREE.MeshBasicMaterial({color:0xffffff}));chest.position.set(0,-1.2,.52);bot.add(chest);
  const arm=(x)=>{const p=new THREE.Group();p.position.set(x*.62,-.95,0);const a=new THREE.Mesh(new THREE.CylinderGeometry(.11,.11,.62,14),mP(0xb79cff));a.position.y=-.3;const h=new THREE.Mesh(new THREE.SphereGeometry(.14,16,12),mP(0xffffff));h.position.y=-.65;p.add(a,h);bot.add(p);return p};
  const armL=arm(-1),armR=arm(1);armL.rotation.z=.35;armR.rotation.z=-.35;

  /* big % number floating on the right */
  const big=label((s.avg_growth_pct>0?'+':'')+s.avg_growth_pct+'%',104,flat?'#ffe27a':up?'#8dffc4':'#ff9cc6',320,160);big.scale.set(2.4,1.2,1);big.position.set(2.2,4.9,1);sc.add(big);

  /* sparkles: burst on open / replay, then drift */
  const NS=160,sp=new Float32Array(NS*3),sv=new Float32Array(NS*3),sg=new THREE.BufferGeometry();sg.setAttribute('position',new THREE.BufferAttribute(sp,3));
  const sparks=new THREE.Points(sg,new THREE.PointsMaterial({size:.12,color:0xffe9a8,transparent:true,opacity:.95,depthWrite:false}));sc.add(sparks);
  function burst(){for(let i=0;i<NS;i++){sp.set([bot.position.x,bot.position.y-.4,bot.position.z],i*3);const a=Math.random()*6.283,b=Math.random()*3.14-1.57,v=1.2+Math.random()*3;sv.set([Math.cos(a)*Math.cos(b)*v,Math.sin(b)*v+1,Math.sin(a)*Math.cos(b)*v],i*3)}}
  burst();
  let t0=performance.now()/1000;
  function replay(){t0=performance.now()/1000;bars.forEach(b=>{b.m.scale.y=.001;b.v.visible=false});burst();type()}

  /* drag to rotate the bars */
  let drag=false,lx=0,rot=0,px=0;
  cv.addEventListener('pointerdown',e=>{drag=true;lx=e.clientX;cv.setPointerCapture(e.pointerId)});
  cv.addEventListener('pointerup',()=>drag=false);
  cv.addEventListener('pointermove',e=>{px=e.clientX/innerWidth-.5;if(drag){rot+=(e.clientX-lx)*.01;lx=e.clientX;rot=Math.max(-1.1,Math.min(1.1,rot))}});

  const ease=x=>1-Math.pow(1-Math.min(Math.max(x,0),1),3),clock=new THREE.Clock();let dt=0;
  (function loop(){if(disposed)return;raf=requestAnimationFrame(loop);
    dt=clock.getDelta();const now=performance.now()/1000,t=now-t0,T2=clock.elapsedTime;
    bars.forEach(b=>{const k=ease((t-.5-b.delay)/.9);b.m.scale.y=Math.max(.001,b.h*k);b.v.position.y=b.m.scale.y+.35;b.v.visible=k>.9});
    const lb=bars[n-1],ls=lb.m.scale.y;arrow.position.set(lb.m.position.x,ls+1.15+Math.sin(T2*3)*.12,0);arrow.rotation.y=T2*1.5;
    root.rotation.y=rot*(drag?1:.97)+Math.sin(T2*.5)*.12;if(!drag)rot*=.995;
    /* robot: float, look toward pointer, blink, talk, wave */
    bot.position.y=5.0+Math.sin(T2*1.8)*.12;bot.rotation.y=px*.5-.1;bot.rotation.x=Math.sin(T2*1.1)*.04;
    const blink=(T2%3.4)>3.3?.1:1;eyes.forEach(e=>e.scale.y=blink);
    mouth.scale.y=talking?.35+Math.abs(Math.sin(T2*14))*1.1:.35;bulb.scale.setScalar(1+Math.sin(T2*5)*.25);
    armR.rotation.z=-.5-Math.sin(T2*(talking?7:3))*(talking?.55:.25);armL.rotation.z=.35+Math.sin(T2*2)*.06;
    const sx=Math.sin(T2*.6)*.04;big.position.y=4.9+Math.sin(T2*1.5)*.1;big.material.rotation=sx;
    for(let i=0;i<NS;i++){sv[i*3+1]-=2.2*dt;sp[i*3]+=sv[i*3]*dt;sp[i*3+1]+=sv[i*3+1]*dt;sp[i*3+2]+=sv[i*3+2]*dt;if(sp[i*3+1]<-1.5){sp[i*3+1]=-1.5;sv[i*3]*=.9;sv[i*3+1]=Math.abs(sv[i*3+1])*.25;sv[i*3+2]*=.9}}
    sg.attributes.position.needsUpdate=true;
    cam.position.x+=(px*1.6-cam.position.x)*.05;cam.lookAt(0,lookY,0);
    R.render(sc,cam)})();
}
