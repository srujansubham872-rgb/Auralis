/* Growth Coach card on the Progress screen (data from /api/me/growth). */
Object.assign(T.en,{gcTitle:'Growth Coach',gcAvg:'Average growth per week',gcPts:'points/week',gcLes:'lessons/week',gcTip:'Next step: try {a}',gcAll:'You finished every lesson. Ask the chatbot a new topic!',gcEmpty:'Complete a lesson to start your growth report.',gcDemo:'See sample report',gcOff:'Start the backend to see your growth report.',gcTap:'Tap to meet your 3D coach',gcSample:'See sample report',gcSound:'Listen',gcAgain:'Replay',gcWeek:'points'});
Object.assign(T.hi,{gcTitle:'ग्रोथ कोच',gcAvg:'हर हफ़्ते औसत प्रगति',gcPts:'अंक/हफ़्ता',gcLes:'पाठ/हफ़्ता',gcTip:'अगला कदम: {a} आज़माइए',gcAll:'आपने सभी पाठ पूरे कर लिए। चैटबॉट से नया विषय पूछिए!',gcEmpty:'ग्रोथ रिपोर्ट शुरू करने के लिए एक पाठ पूरा कीजिए।',gcDemo:'नमूना रिपोर्ट देखें',gcOff:'ग्रोथ रिपोर्ट देखने के लिए बैकएंड चालू कीजिए।',gcTap:'अपने 3D कोच से मिलने के लिए छूइए',gcSample:'नमूना रिपोर्ट देखें',gcSound:'सुनिए',gcAgain:'फिर से',gcWeek:'अंक'});
Object.assign(T.or,{gcTitle:'ଗ୍ରୋଥ୍ କୋଚ୍',gcAvg:'ପ୍ରତି ସପ୍ତାହ ହାରାହାରି ପ୍ରଗତି',gcPts:'ପଏଣ୍ଟ/ସପ୍ତାହ',gcLes:'ପାଠ/ସପ୍ତାହ',gcTip:'ପରବର୍ତ୍ତୀ ପଦକ୍ଷେପ: {a} ଚେଷ୍ଟା କରନ୍ତୁ',gcAll:'ଆପଣ ସବୁ ପାଠ ଶେଷ କଲେ। ଚାଟବଟ୍‌କୁ ନୂଆ ବିଷୟ ପଚାରନ୍ତୁ!',gcEmpty:'ଗ୍ରୋଥ୍ ରିପୋର୍ଟ ଆରମ୍ଭ କରିବାକୁ ଗୋଟିଏ ପାଠ ସମାପ୍ତ କରନ୍ତୁ।',gcDemo:'ନମୁନା ରିପୋର୍ଟ ଦେଖନ୍ତୁ',gcOff:'ଗ୍ରୋଥ୍ ରିପୋର୍ଟ ଦେଖିବାକୁ ବ୍ୟାକେଣ୍ଡ ଚଲାନ୍ତୁ।',gcTap:'ଆପଣଙ୍କ 3D କୋଚ୍‌କୁ ଭେଟିବାକୁ ଛୁଅନ୍ତୁ',gcSample:'ନମୁନା ରିପୋର୍ଟ ଦେଖନ୍ତୁ',gcSound:'ଶୁଣନ୍ତୁ',gcAgain:'ପୁଣି',gcWeek:'ପଏଣ୍ଟ'});
Object.assign(T.ur,{gcTitle:'گروتھ کوچ',gcAvg:'ہر ہفتے اوسط ترقی',gcPts:'پوائنٹس/ہفتہ',gcLes:'اسباق/ہفتہ',gcTip:'اگلا قدم: {a} آزمائیں',gcAll:'آپ نے تمام اسباق مکمل کر لیے۔ چیٹ بوٹ سے نیا موضوع پوچھیں!',gcEmpty:'گروتھ رپورٹ شروع کرنے کے لیے ایک سبق مکمل کریں۔',gcDemo:'نمونہ رپورٹ دیکھیں',gcOff:'گروتھ رپورٹ دیکھنے کے لیے بیک اینڈ چلائیں۔',gcTap:'اپنے 3D کوچ سے ملنے کے لیے چھوئیں',gcSample:'نمونہ رپورٹ دیکھیں',gcSound:'سنیں',gcAgain:'دوبارہ',gcWeek:'پوائنٹس'});
/* Local growth report (used when the backend is off, so the Growth Coach always has an answer). Same maths as backend/growth.py */
const GL={en:{head:'{name}, your average weekly growth is {g}% — {p} points and {l} lessons a week.',up:'This week is better than last week ({c} points). Great work!',down:'This week is a little lower ({c} points). A short lesson today will fix it.',flat:'This week matches last week ({c} points). Keep going!'},
 hi:{head:'{name}, आपकी औसत साप्ताहिक प्रगति {g}% है — हफ़्ते में {p} अंक और {l} पाठ।',up:'यह हफ़्ता पिछले हफ़्ते से बेहतर है ({c} अंक)। शाबाश!',down:'यह हफ़्ता थोड़ा कम है ({c} अंक)। आज एक छोटा पाठ इसे ठीक कर देगा।',flat:'यह हफ़्ता पिछले हफ़्ते जैसा है ({c} अंक)। लगे रहिए!'},
 or:{head:'{name}, ଆପଣଙ୍କ ହାରାହାରି ସାପ୍ତାହିକ ପ୍ରଗତି {g}% — ସପ୍ତାହକୁ {p} ପଏଣ୍ଟ ଓ {l} ପାଠ।',up:'ଏହି ସପ୍ତାହ ଗତ ସପ୍ତାହଠାରୁ ଭଲ ({c} ପଏଣ୍ଟ)। ବହୁତ ବଢ଼ିଆ!',down:'ଏହି ସପ୍ତାହ ଟିକେ କମ୍ ({c} ପଏଣ୍ଟ)। ଆଜି ଗୋଟିଏ ଛୋଟ ପାଠ ଏହାକୁ ଠିକ୍ କରିଦେବ।',flat:'ଏହି ସପ୍ତାହ ଗତ ସପ୍ତାହ ପରି ({c} ପଏଣ୍ଟ)। ଚାଲିଥାଆନ୍ତୁ!'},
 ur:{head:'{name}، آپ کی اوسط ہفتہ وار ترقی {g}% ہے — ہفتے میں {p} پوائنٹس اور {l} اسباق۔',up:'یہ ہفتہ پچھلے ہفتے سے بہتر ہے ({c} پوائنٹس)۔ شاباش!',down:'یہ ہفتہ کچھ کم ہے ({c} پوائنٹس)۔ آج ایک مختصر سبق اسے ٹھیک کر دے گا۔',flat:'یہ ہفتہ پچھلے ہفتے جیسا ہے ({c} پوائنٹس)۔ لگے رہیں!'}};
const _mon=d=>{const x=new Date(d);x.setHours(0,0,0,0);x.setDate(x.getDate()-((x.getDay()+6)%7));return x};
const _lbl=d=>String(d.getDate()).padStart(2,'0')+' '+['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
function mkWeeks(list){return list.slice(-8)}
function localWeekly(){
  if(!S.ev.length)return[];
  const m0=_mon(Math.min(...S.ev.map(e=>e.at))),n=Math.round((_mon(Date.now())-m0)/6048e5)+1;
  const w=[...Array(Math.max(n,1))].map((_,i)=>({week:_lbl(new Date(m0.getTime()+i*6048e5)),lessons:0,questions:0,points:0}));
  S.ev.forEach(e=>{const i=Math.round((_mon(e.at)-m0)/6048e5);if(w[i]){w[i][e.k==='lesson'?'lessons':'questions']++;w[i].points+=e.k==='lesson'?10:2}});
  return mkWeeks(w)}
function demoWeeks(){return mkWeeks([[1,2],[1,3],[2,3],[2,5],[3,6],[4,8]].map(([l,q],i)=>({week:_lbl(new Date(Date.now()-(5-i)*6048e5)),lessons:l,questions:q,points:l*10+q*2})))}
function analyzeJS(weeks){
  const p=weeks.map(w=>w.points),n=p.length,ch=[];for(let i=1;i<n;i++)if(p[i-1]>0)ch.push((p[i]-p[i-1])/p[i-1]*100);
  const prev=n>1?p[n-2]:null;let streak=0;for(let i=n-1;i>=0&&p[i]>0;i--)streak++;
  const r1=x=>Math.round(x*10)/10;
  return{weeks,avg_points:r1(p.reduce((a,b)=>a+b,0)/n),avg_lessons:r1(weeks.reduce((a,w)=>a+w.lessons,0)/n),avg_growth_pct:ch.length?r1(ch.reduce((a,b)=>a+b,0)/ch.length):0,
   current:p[n-1],previous:prev,streak_weeks:streak,best_week:weeks.reduce((a,w)=>w.points>a.points?w:a,weeks[0]).week,
   trend:prev===null||p[n-1]===prev?'flat':p[n-1]>prev?'up':'down'}}
function narrateJS(s){const x=GL[S.lang]||GL.en;return(x.head+' '+x[s.trend]).replace('{name}',S.user.name).replace('{g}',(s.avg_growth_pct>=0?'+':'')+s.avg_growth_pct.toFixed(1)).replace('{p}',s.avg_points).replace('{l}',s.avg_lessons).replace('{c}',s.current)}

async function growthData(demo){
  let g=DB.tok?await DB.call('/api/me/growth?lang='+S.lang+(demo?'&demo=1':'')):null;
  let stats,message,src;
  if(g&&g.stats){stats=g.stats;message=g.message;src=g.agent;demo=g.demo}
  else{const w=demo?demoWeeks():localWeekly();if(!w.length)return null;stats=analyzeJS(w);message=narrateJS(stats);src='local'}
  const nx=LESSONS.find(l=>l.id===stats.next_lesson)||(!stats.next_lesson&&LESSONS.find(l=>!S.done.has(l.id)));
  const tip=nx?t('gcTip').replace('{a}',nx.title[li()]):t('gcAll');
  return{stats,message,tip,demo:!!demo,src}}

async function growthCard(demo){
 const box=document.getElementById('growth');if(!box)return;
 const wrap=h=>box.innerHTML=`<div class="card gc"><b>🤖 ${t('gcTitle')}</b>${h}</div>`;
 const g=await growthData(demo);
 if(!g)return wrap(`<p class="sm">${t('gcEmpty')}</p><button class="btn small" id="gdemo">${t('gcDemo')}</button>`),document.getElementById('gdemo').onclick=()=>growthCard(1);
 const s=g.stats,mx=Math.max(...s.weeks.map(w=>w.points),1);
 wrap(`<div class="gtop"><div class="big ${s.trend==='down'?'dn':'up'}">${s.trend==='up'?'▲':s.trend==='down'?'▼':'▬'} ${s.avg_growth_pct>0?'+':''}${s.avg_growth_pct}%</div><div><p class="sm">${t('gcAvg')}</p><p class="sm">${s.avg_points} ${t('gcPts')} · ${s.avg_lessons} ${t('gcLes')}</p></div></div>
 <div class="gbars">${s.weeks.map(w=>`<div><i style="height:${w.points/mx*100}%"></i><small>${w.week}</small></div>`).join('')}</div>
 <p class="gmsg">${esc(g.message)} ${esc(g.tip)}</p><p class="sm">🏆 ${s.best_week} · 🔥 ${s.streak_weeks}${g.demo?' · demo':''}</p><span class="gtap">🧊 ${t('gcTap')}</span>`);
 box.firstChild.onclick=()=>growth3D(g);        // click the Growth Coach -> 3D animated answer
}
