/* Auralis 3D layer (Three.js r128): glowing AI orb + rings + particle field behind every screen. */
(()=>{
if(!window.THREE)return;
const app=document.getElementById('app'),cv=document.createElement('canvas');cv.id='bg3d';app.prepend(cv);
const R=new THREE.WebGLRenderer({canvas:cv,alpha:true,antialias:true});R.setPixelRatio(Math.min(devicePixelRatio,2));
const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(50,1,.1,100);cam.position.z=6;
function size(){const w=app.clientWidth,h=app.clientHeight;R.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix()}
size();addEventListener('resize',size);
sc.add(new THREE.AmbientLight(0xcbb8ff,.8));
const l1=new THREE.PointLight(0xb79cff,2.2,30);l1.position.set(4,4,5);
const l2=new THREE.PointLight(0xff7ac8,1.6,30);l2.position.set(-5,-2,4);sc.add(l1,l2);
const orb=new THREE.Group();sc.add(orb);
const core=new THREE.Mesh(new THREE.IcosahedronGeometry(1.1,3),new THREE.MeshStandardMaterial({color:0x7a52f0,emissive:0x3d1fa8,emissiveIntensity:.6,metalness:.4,roughness:.25,flatShading:true}));
const wire=new THREE.Mesh(new THREE.IcosahedronGeometry(1.45,2),new THREE.MeshBasicMaterial({color:0xd8c8ff,wireframe:true,transparent:true,opacity:.35}));
const halo=new THREE.Mesh(new THREE.SphereGeometry(1.9,32,32),new THREE.MeshBasicMaterial({color:0xb79cff,transparent:true,opacity:.12}));
const rings=[0,1].map(i=>{const m=new THREE.Mesh(new THREE.TorusGeometry(1.9+i*.4,.025,8,120),new THREE.MeshBasicMaterial({color:i?0xff9ccf:0xffffff}));m.rotation.x=1.2+i*.5;orb.add(m);return m});
orb.add(core,wire,halo);
const N=700,pos=new Float32Array(N*3),col=new Float32Array(N*3),c1=new THREE.Color(0x8f6bff),c2=new THREE.Color(0xff7ac8);
for(let i=0;i<N;i++){pos.set([(Math.random()-.5)*16,(Math.random()-.5)*16,(Math.random()-.5)*10-2],i*3);const c=c1.clone().lerp(c2,Math.random());col.set([c.r,c.g,c.b],i*3)}
const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));g.setAttribute('color',new THREE.BufferAttribute(col,3));
const pts=new THREE.Points(g,new THREE.PointsMaterial({size:.06,vertexColors:true,transparent:true,opacity:.85}));sc.add(pts);
/* orb position per screen: big in the middle on splash, small in the top corner elsewhere */
let tgt=[0,1,.7],px=0,py=0,boost=0;
window.orb3d=id=>{tgt=id==='splash'?[0,1,.7]:[.85,2.3,.3]};
window.orbBoost=()=>{boost=1};
addEventListener('pointermove',e=>{px=e.clientX/innerWidth-.5;py=e.clientY/innerHeight-.5});
const clk=new THREE.Clock();
(function loop(){const t=clk.getElapsedTime();
 orb.position.x+=(tgt[0]-orb.position.x)*.06;orb.position.y+=(tgt[1]-orb.position.y)*.06;
 const s=orb.scale.x+(tgt[2]*(1+boost*.3)-orb.scale.x)*.08;orb.scale.setScalar(s);boost*=.95;
 core.rotation.y=t*.4;core.rotation.x=t*.2;wire.rotation.y=-t*.25;wire.rotation.z=t*.15;
 rings[0].rotation.z=t*.6;rings[1].rotation.z=-t*.45;halo.scale.setScalar(1+Math.sin(t*2)*.04);
 pts.rotation.y=t*.03;pts.rotation.x=py*.1;
 cam.position.x+=(px*1.2-cam.position.x)*.05;cam.position.y+=(-py*1.2-cam.position.y)*.05;cam.lookAt(0,0,0);
 R.render(sc,cam);requestAnimationFrame(loop)})();
/* 3D tilt on cards */
const T='.opt,#recList .card,#exList .card,.chatcta,.plan';
document.addEventListener('pointermove',e=>{const c=e.target.closest&&e.target.closest(T);if(!c)return;const r=c.getBoundingClientRect();
 c.style.transform=`perspective(600px) rotateX(${-((e.clientY-r.top)/r.height-.5)*14}deg) rotateY(${((e.clientX-r.left)/r.width-.5)*14}deg) translateZ(8px)`});
document.addEventListener('pointerout',e=>{const c=e.target.closest&&e.target.closest(T);if(c)c.style.transform=''});
})();
