/* Talks to the FastAPI + Neo4j backend. If the backend is off, the app keeps working as a local demo. */
const BASE=(location.protocol==='file:'||location.port==='3000')?'http://localhost:8000':'';
const DB={tok:null,
 h(){return{'Content-Type':'application/json',...(this.tok?{Authorization:'Bearer '+this.tok}:{})}},
 async call(path,method='GET',body){try{const r=await fetch(BASE+path,{method,headers:this.h(),body:body&&JSON.stringify(body)});
   if(!r.ok)return{error:r.status};return await r.json()}catch{return null}},
 signup(u){return this.call('/api/auth/signup','POST',u)},
 async verify(contact,otp){const r=await this.call('/api/auth/verify','POST',{contact,otp});
   if(!r)return null;if(r.error)return r.error===400?'bad':null;this.tok=r.token;return restore(r.student)},
 save(f){return this.tok&&this.call('/api/me','PUT',f)},
 done(id){return this.tok&&this.call('/api/progress','POST',{lesson_id:id})},
 addRem(r){return this.tok&&this.call('/api/reminders','POST',r)},
 delRem(id){return this.tok&&this.call('/api/reminders/'+id,'DELETE')}};
/* Load a returning student's saved data into the app */
function restore(st){if(!st)return null;
 Object.assign(S.user,{name:st.name||S.user.name,gender:st.gender,age:st.age,contact:st.contact});
 S.lang=st.language||'en';S.cats=new Set((st.categories||[]).map(c=>+c.slice(1)-1));S.done=new Set(st.done||[]);
 S.rem=(st.reminders||[]).map(r=>({id:r.id,a:r.lesson,d:r.date,t:r.time,rep:r.repeat,on:r.active}));S.plan=st.plan||undefined;
 $$('#catCards .opt').forEach((c,i)=>c.classList.toggle('sel',S.cats.has(i)));
 $$('#langCards .opt').forEach((c,i)=>c.classList.toggle('sel',LANGS[i].c===S.lang));
 applyLang();return st}
