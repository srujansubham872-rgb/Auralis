/* Auto exam planner + auto follow-up questions.
   - When the student finishes EVERY lesson, an exam plan is built automatically (day-by-day: revise -> practice -> mock test -> exam day),
     reminders are added for each day, and practice questions are generated (AI via backend if an API key is set, local templates otherwise).
   - After EVERY lesson, follow-up questions are added automatically (completion screen + chat). */
Object.assign(T.en,{examPlan:'Exam plan',examReady:'Your exam plan is ready!',examGo:'Open my exam plan',examLock:'Finish all {n} lessons and Auralis will plan your exam automatically.',examLeft:'{a}/{b} lessons done',examDate:'Exam date',examDays:'Study plan',dayN:'Day {n}',tdy:'Tomorrow',
 revise:'Revise',practice:'Practice',mock:'Mock test',examDay:'Exam day',minutes:'min',tRev1:'Redo every step of "{a}" once.',tRev2:'Write the key points in your own words.',tPra1:'Do "{a}" again without looking.',tPra2:'Ask Auralis two questions about "{a}".',
 tMock1:'Do all lessons one after another from memory.',tMock2:'Ask Auralis to quiz you.',tExam1:'Quick look at your notes. Sleep well.',tExam2:'Stay calm. You are ready!',askAura:'Ask Auralis',quizMe:'Quiz me on all my lessons',
 followT:'Follow-up questions added for you',fq1:'Why is each step in "{a}" important?',fq2:'How can I practise "{a}" at home?',fq3:'What is a common mistake in "{a}"?',practiceQ:'Practice questions',once:'once',chatHi:'Hi! Ask me anything. I also add follow-up questions after every lesson.',examMsg:'You finished the whole course! Auralis made a plan for your exam. One small step each day is enough.',thinking:'Thinking…'});
Object.assign(T.hi,{examPlan:'परीक्षा योजना',examReady:'आपकी परीक्षा योजना तैयार है!',examGo:'मेरी परीक्षा योजना खोलें',examLock:'सभी {n} पाठ पूरे कीजिए, ऑरालिस अपने आप आपकी परीक्षा की योजना बना देगा।',examLeft:'{a}/{b} पाठ पूरे',examDate:'परीक्षा की तारीख़',examDays:'पढ़ाई की योजना',dayN:'दिन {n}',tdy:'कल',
 revise:'दोहराइए',practice:'अभ्यास',mock:'मॉक टेस्ट',examDay:'परीक्षा का दिन',minutes:'मिनट',tRev1:'"{a}" के हर चरण को एक बार दोहराइए।',tRev2:'मुख्य बातें अपने शब्दों में लिखिए।',tPra1:'"{a}" को बिना देखे फिर से कीजिए।',tPra2:'ऑरालिस से "{a}" पर दो सवाल पूछिए।',
 tMock1:'सभी पाठ याद से एक के बाद एक कीजिए।',tMock2:'ऑरालिस से अपना टेस्ट लेने को कहिए।',tExam1:'अपने नोट्स पर एक नज़र डालिए। अच्छी नींद लीजिए।',tExam2:'शांत रहिए। आप तैयार हैं!',askAura:'ऑरालिस से पूछें',quizMe:'मेरे सभी पाठों पर मेरा टेस्ट लो',
 followT:'आपके लिए जोड़े गए अगले सवाल',fq1:'"{a}" का हर चरण क्यों ज़रूरी है?',fq2:'मैं घर पर "{a}" का अभ्यास कैसे करूँ?',fq3:'"{a}" में आम गलती क्या होती है?',practiceQ:'अभ्यास के सवाल',once:'एक बार',chatHi:'नमस्ते! कुछ भी पूछिए। हर पाठ के बाद मैं अगले सवाल भी जोड़ता हूँ।',examMsg:'आपने पूरा कोर्स पूरा कर लिया! ऑरालिस ने आपकी परीक्षा की योजना बना दी। रोज़ एक छोटा कदम काफ़ी है।',thinking:'सोच रहा हूँ…'});
Object.assign(T.or,{examPlan:'ପରୀକ୍ଷା ଯୋଜନା',examReady:'ଆପଣଙ୍କ ପରୀକ୍ଷା ଯୋଜନା ପ୍ରସ୍ତୁତ!',examGo:'ମୋ ପରୀକ୍ଷା ଯୋଜନା ଖୋଲନ୍ତୁ',examLock:'ସବୁ {n} ପାଠ ଶେଷ କରନ୍ତୁ, ଔରାଲିସ୍ ନିଜେ ଆପଣଙ୍କ ପରୀକ୍ଷା ଯୋଜନା କରିଦେବ।',examLeft:'{a}/{b} ପାଠ ସମାପ୍ତ',examDate:'ପରୀକ୍ଷା ତାରିଖ',examDays:'ପଢ଼ା ଯୋଜନା',dayN:'ଦିନ {n}',tdy:'କାଲି',
 revise:'ପୁନର୍ବାର ପଢ଼ନ୍ତୁ',practice:'ଅଭ୍ୟାସ',mock:'ମକ୍ ଟେଷ୍ଟ',examDay:'ପରୀକ୍ଷା ଦିନ',minutes:'ମିନିଟ୍',tRev1:'"{a}" ର ପ୍ରତି ପଦକ୍ଷେପ ଥରେ ଦୋହରାନ୍ତୁ।',tRev2:'ମୁଖ୍ୟ କଥା ନିଜ ଶବ୍ଦରେ ଲେଖନ୍ତୁ।',tPra1:'"{a}" ଦେଖିବା ବିନା ପୁଣି କରନ୍ତୁ।',tPra2:'ଔରାଲିସ୍‌କୁ "{a}" ବିଷୟରେ ଦୁଇଟି ପ୍ରଶ୍ନ ପଚାରନ୍ତୁ।',
 tMock1:'ସବୁ ପାଠ ମନେ ରଖି ଗୋଟିକ ପରେ ଗୋଟିଏ କରନ୍ତୁ।',tMock2:'ଔରାଲିସ୍‌କୁ ଆପଣଙ୍କ ପରୀକ୍ଷା ନେବାକୁ କୁହନ୍ତୁ।',tExam1:'ନିଜ ନୋଟ୍ ଉପରେ ଥରେ ନଜର ପକାନ୍ତୁ। ଭଲ ନିଦ ଯାଆନ୍ତୁ।',tExam2:'ଶାନ୍ତ ରୁହନ୍ତୁ। ଆପଣ ପ୍ରସ୍ତୁତ!',askAura:'ଔରାଲିସ୍‌କୁ ପଚାରନ୍ତୁ',quizMe:'ମୋ ସବୁ ପାଠ ଉପରେ ମୋ ପରୀକ୍ଷା ନିଅ',
 followT:'ଆପଣଙ୍କ ପାଇଁ ଯୋଡ଼ାଯାଇଥିବା ପରବର୍ତ୍ତୀ ପ୍ରଶ୍ନ',fq1:'"{a}" ର ପ୍ରତି ପଦକ୍ଷେପ କାହିଁକି ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ?',fq2:'ମୁଁ ଘରେ "{a}" କିପରି ଅଭ୍ୟାସ କରିବି?',fq3:'"{a}" ରେ ସାଧାରଣ ଭୁଲ କ’ଣ?',practiceQ:'ଅଭ୍ୟାସ ପ୍ରଶ୍ନ',once:'ଥରେ',chatHi:'ନମସ୍କାର! ଯାହା ଇଚ୍ଛା ପଚାରନ୍ତୁ। ପ୍ରତି ପାଠ ପରେ ମୁଁ ପରବର୍ତ୍ତୀ ପ୍ରଶ୍ନ ମଧ୍ୟ ଯୋଡ଼େ।',examMsg:'ଆପଣ ସମ୍ପୂର୍ଣ୍ଣ କୋର୍ସ ଶେଷ କଲେ! ଔରାଲିସ୍ ପରୀକ୍ଷା ଯୋଜନା କରିଦେଲା। ପ୍ରତିଦିନ ଗୋଟିଏ ଛୋଟ ପଦକ୍ଷେପ ଯଥେଷ୍ଟ।',thinking:'ଭାବୁଛି…'});
Object.assign(T.ur,{examPlan:'امتحان کا منصوبہ',examReady:'آپ کا امتحانی منصوبہ تیار ہے!',examGo:'میرا امتحانی منصوبہ کھولیں',examLock:'تمام {n} اسباق مکمل کریں، اورالس خود آپ کے امتحان کا منصوبہ بنا دے گا۔',examLeft:'{a}/{b} اسباق مکمل',examDate:'امتحان کی تاریخ',examDays:'مطالعے کا منصوبہ',dayN:'دن {n}',tdy:'کل',
 revise:'دہرائیں',practice:'مشق',mock:'ماک ٹیسٹ',examDay:'امتحان کا دن',minutes:'منٹ',tRev1:'"{a}" کے ہر مرحلے کو ایک بار دہرائیں۔',tRev2:'اہم باتیں اپنے الفاظ میں لکھیں۔',tPra1:'"{a}" کو دیکھے بغیر دوبارہ کریں۔',tPra2:'اورالس سے "{a}" پر دو سوال پوچھیں۔',
 tMock1:'تمام اسباق یاد سے ایک کے بعد ایک کریں۔',tMock2:'اورالس سے اپنا ٹیسٹ لینے کو کہیں۔',tExam1:'اپنے نوٹس پر ایک نظر ڈالیں۔ اچھی نیند لیں۔',tExam2:'پرسکون رہیں۔ آپ تیار ہیں!',askAura:'اورالس سے پوچھیں',quizMe:'میرے تمام اسباق پر میرا ٹیسٹ لو',
 followT:'آپ کے لیے شامل کیے گئے اگلے سوال',fq1:'"{a}" کا ہر مرحلہ کیوں اہم ہے؟',fq2:'میں گھر پر "{a}" کی مشق کیسے کروں؟',fq3:'"{a}" میں عام غلطی کیا ہوتی ہے؟',practiceQ:'مشق کے سوال',once:'ایک بار',chatHi:'سلام! کچھ بھی پوچھیں۔ ہر سبق کے بعد میں اگلے سوال بھی شامل کرتا ہوں۔',examMsg:'آپ نے پورا کورس مکمل کر لیا! اورالس نے آپ کے امتحان کا منصوبہ بنا دیا۔ روز ایک چھوٹا قدم کافی ہے۔',thinking:'سوچ رہا ہوں…'});

/* ---------- local persistence (works without the backend) ---------- */
const lkey=()=>'auralis_'+(S.user.contact||'guest');
function persist(){try{localStorage.setItem(lkey(),JSON.stringify({ev:S.ev,exam:S.exam,follow:S.follow,done:[...S.done]}))}catch{}}
function loadLocal(){try{const d=JSON.parse(localStorage.getItem(lkey())||'null');if(!d)return;
  S.ev=d.ev||S.ev;S.exam=d.exam||S.exam;S.follow=d.follow||S.follow;(d.done||[]).forEach(x=>S.done.add(x))}catch{}}
function logEv(k,id){S.ev.push({k,id,at:Date.now()});persist()}

/* ---------- helpers ---------- */
const iso=d=>{const z=new Date(d.getTime()-d.getTimezoneOffset()*6e4);return z.toISOString().slice(0,10)};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const lt=(id)=>{const L=LESSONS.find(l=>l.id===id);return L?L.title[li()]:t('examPlan')};
const courseDone=()=>LESSONS.every(l=>S.done.has(l.id));

/* ---------- follow-up questions after each lesson ---------- */
function localFollow(L){return['fq1','fq2','fq3'].map(k=>({lesson:L.id,q:t(k).replace('{a}',L.title[li()])}))}
async function autoFollow(L){
  let qs=localFollow(L);
  const r=await DB.call('/api/followups','POST',{lang:S.lang,lesson:{id:L.id,title:L.title[li()],steps:L.steps.map(s=>s[1])}});
  if(r&&r.questions&&r.questions.length)qs=r.questions.map(q=>({lesson:L.id,q}));
  S.follow=S.follow.filter(f=>f.lesson!==L.id).concat(qs);S.followNew=true;persist();return qs;
}
const chips=(qs)=>qs.map(f=>`<span class="fq" data-q="1">${esc(f.q)}</span>`).join('');

/* ---------- the exam plan ---------- */
function buildExam(dateStr){
  const today=new Date();today.setHours(0,0,0,0);
  let end=dateStr?new Date(dateStr+'T00:00:00'):addDays(today,7);
  let n=Math.round((end-today)/864e5);n=Math.max(3,Math.min(n,30));end=addDays(today,n);       // 3..30 days from today
  const L=LESSONS,days=[];
  for(let i=1;i<=n;i++){
    const date=iso(addDays(today,i));let d;
    if(i===n)d={type:'exam',lesson:null,min:30};
    else if(i===n-1)d={type:'mock',lesson:null,min:40};
    else{const k=Math.floor((i-1)/2)%L.length;d={type:i%2?'revise':'practice',lesson:L[k].id,min:i%2?20:15}}
    days.push({...d,n:i,date})}
  S.exam={date:iso(end),days,msg:'',questions:[],tips:{}};
  S.exam.questions=LESSONS.flatMap(localFollow).slice(0,12);
  setExamReminders();persist();enrichExam();return S.exam;
}
/* reminders for each plan day (ids start with "ex" so a re-plan can replace them) */
function setExamReminders(){
  S.rem.filter(r=>String(r.id).startsWith('ex')).forEach(r=>DB.delRem(r.id));
  S.rem=S.rem.filter(r=>!String(r.id).startsWith('ex'));
  S.exam.days.forEach(d=>{const r={id:'ex'+d.n+Date.now().toString(36),a:d.lesson||'exam',d:d.date,t:'18:00',rep:'once',on:true};S.rem.push(r);DB.addRem(r)});
}
async function enrichExam(){      // AI message + questions + tips (needs backend; skipped silently when offline)
  const ex=S.exam;if(!ex)return;
  const r=await DB.call('/api/exam/insights','POST',{lang:S.lang,days:ex.days.length,lessons:LESSONS.map(l=>({id:l.id,title:l.title[li()]}))});
  if(S.exam!==ex||!r||r.error)return;
  if(r.message)ex.msg=r.message;if(r.questions&&r.questions.length)ex.questions=r.questions;if(r.tips)ex.tips=r.tips;
  persist();if(S.cur==='exam')examScreen();
}
function ensureExam(){if(courseDone()&&!S.exam)buildExam()}

const TYPE={revise:['📖','revise','tRev1','tRev2'],practice:['✏️','practice','tPra1','tPra2'],mock:['📝','mock','tMock1','tMock2'],exam:['🎓','examDay','tExam1','tExam2']};
function examScreen(){
  const box=document.getElementById('examBody');if(!box)return;
  if(!courseDone()){const n=LESSONS.filter(l=>S.done.has(l.id)).length;
    box.innerHTML=`<div class="card" style="text-align:center"><div style="font-size:54px">🔒</div><p>${t('examLock').replace('{n}',LESSONS.length)}</p><b>${t('examLeft').replace('{a}',n).replace('{b}',LESSONS.length)}</b></div>`;return}
  ensureExam();const ex=S.exam;
  const days=ex.days.map((d,i)=>{const y=TYPE[d.type],a=d.lesson?lt(d.lesson):'';
    const q=d.type==='mock'||d.type==='exam'?t('quizMe'):t('fq1').replace('{a}',a);
    return `<div class="card eday ${d.type}" style="animation-delay:${i*.05}s"><div class="edh"><span class="eic">${y[0]}</span><div><b>${t('dayN').replace('{n}',d.n)} · ${t(y[1])}</b><p class="sm">${d.n===1?t('tdy')+' · ':''}${d.date} · ${d.min} ${t('minutes')}</p></div></div>
      <ul><li>${t(y[2]).replace('{a}',a)}</li><li>${t(y[3]).replace('{a}',a)}</li></ul>${d.lesson&&ex.tips[d.lesson]?`<div class="tip">💡 <b>${t('tip')}:</b> ${esc(ex.tips[d.lesson])}</div>`:''}
      <button class="fq" data-q="1" data-text="${esc(q)}">💬 ${t('askAura')}</button></div>`}).join('');
  box.innerHTML=`<div class="card"><p class="gmsg">🎓 ${esc(ex.msg||t('examMsg'))}</p><label>${t('examDate')}</label><input type="date" id="exDate" value="${ex.date}" min="${iso(addDays(new Date(),3))}" max="${iso(addDays(new Date(),30))}"></div>
    <div class="card"><b>${t('practiceQ')}</b><div>${chips(ex.questions)}</div></div><h3>${t('examDays')}</h3>${days}`;
  document.getElementById('exDate').onchange=e=>{if(e.target.value){buildExam(e.target.value);examScreen()}};
}
/* tapping any question chip (exam plan, completion screen, chat) sends it to Auralis */
document.addEventListener('click',e=>{const c=e.target.closest&&e.target.closest('.fq[data-q]');if(!c)return;
  const q=c.dataset.text||c.textContent.replace('💬','').trim();if(S.cur!=='chat')go('chat');ask(q)});
