/* Animated 3D explanation (Three.js r128): the coach walks the student through their numbers in 5 scenes
   (points -> weekly growth -> streak -> goal -> next step). Each scene has its own 3D animation, a typed caption and optional voice.
   Auto-plays; Play/Pause, Back/Next, scene dots, voice on/off. Falls back to captions only if WebGL is missing. */
function coachTour(m){
  const app=document.getElementById('app');
  const lessonsPct=Math.round(m.done/LESSONS.length*100);
  const x4=m.goalPct>=100?t('t4b'):cfmt(t('t4a'),{r:Math.max(0,m.goal-m.thisWeek)});
  const steps=[
   {h:t('t1h'),txt:t('t1'),scene:1},
   {h:t('t2h'),txt:m.lastWeek>0?cfmt(t('t2a'),{c:m.thisWeek,p:m.lastWeek,g:(m.growth>0?'+':'')+m.growth}):cfmt(t('t2b'),{c:m.thisWeek}),scene:2},
   {h:t('t3h'),txt:cfmt(t('t3'),{d:m.active14,s:m.streak}),scene:3},
   {h:t('t4h'),txt:cfmt(t('t4'),{g:m.goal,c:m.thisWeek,p:m.goalPct,x:x4}),scene:4},
   {h:t('t5h'),txt:m.next?cfmt(t('t5'),{a:m.next.title[li()]}):t('t5b'),scene:5}];
  const ov=document.createElement('div');ov.id='ctour';
  ov.innerHTML=`<canvas></canvas><button class="gclose" aria-label="${t('tClose')}">✕</button>
   <div class="gpanel"><div class="tdots">${steps.map((_,i)=>`<i data-i="${i}"></i>`).join('')}</div><b class="th"></b><p class="gtxt"></p>
   <div class="tctl"><button id="tPrev" aria-label="${t('tPrev')}">⏮</button><button id="tPlay" class="pri" aria-label="${t('tPause')}">⏸</button><button id="tNext" aria-label="${t('tNext')}">⏭</button><button id="tVoice" aria-label="${t('tSound')}">🔊</button></div></div>`;
  app.append(ov);
  const cv=ov.querySelector('canvas'),txt=ov.querySelector('.gtxt'),head=ov.querySelector('.th'),dots=[...ov.querySelectorAll('.tdots i')];
  let idx=-1,playing=true,voice=!!window.speechSynthesis,typed=true,speaking=false,holdAt=0,typeTimer=0,raf=0,disposed=false,R=null,sceneT0=0,stepStart=0;
  const seg=s=>{try{return[...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(s)].map(x=>x.segment)}catch{return Array.from(s)}};

  /* ---------- text / voice / flow ---------- */
  function setStep(i){
    idx=Math.max(0,Math.min(steps.length-1,i));const st=steps[idx];stepStart=performance.now();sceneT0=stepStart/1000;
    dots.forEach((d,k)=>d.className=k<idx?'done':k===idx?'on':'');head.textContent=st.h;
    clearInterval(typeTimer);txt.textContent='';txt.classList.remove('done');typed=false;holdAt=0;const ch=seg(st.txt);let n=0;
    typeTimer=setInterval(()=>{txt.textContent+=ch[n++];if(n>=ch.length){clearInterval(typeTimer);txt.classList.add('done');typed=true;holdAt=performance.now()}},30);
    speak(st.txt);enter(st.scene)}
  function speak(s){speaking=false;if(!window.speechSynthesis)return;speechSynthesis.cancel();if(!voice||!playing)return;
    const u=new SpeechSynthesisUtterance(s);u.lang=SPEECH[S.lang];u.onstart=()=>{speaking=true;if(bot)bot.talk=true};u.onend=u.onerror=()=>{speaking=false};speechSynthesis.speak(u)}
  function togglePlay(){playing=!playing;const b=ov.querySelector('#tPlay');b.textContent=playing?'⏸':'▶';b.setAttribute('aria-label',t(playing?'tPause':'tPlay'));
    if(!playing){window.speechSynthesis&&speechSynthesis.pause()}else{window.speechSynthesis&&speechSynthesis.paused?speechSynthesis.resume():null;if(typed)holdAt=performance.now()}}
  function close(){if(disposed)return;disposed=true;cancelAnimationFrame(raf);clearInterval(typeTimer);window.speechSynthesis&&speechSynthesis.cancel();document.removeEventListener('keydown',onKey);removeEventListener('resize',resize);
    try{R&&R.dispose()}catch{}ov.remove()}
  const onKey=e=>{if(e.key==='Escape')close();else if(e.key==='ArrowRight')setStep(idx+1);else if(e.key==='ArrowLeft')setStep(idx-1);else if(e.key===' '){e.preventDefault();togglePlay()}};
  document.addEventListener('keydown',onKey);
  ov.querySelector('.gclose').onclick=close;ov.querySelector('#tPlay').onclick=togglePlay;ov.querySelector('#tNext').onclick=()=>setStep(idx+1);ov.querySelector('#tPrev').onclick=()=>setStep(idx-1);
  ov.querySelector('#tVoice').onclick=e=>{voice=!voice;e.target.textContent=voice?'🔊':'🔇';if(voice)speak(steps[idx].txt);else window.speechSynthesis&&speechSynthesis.cancel()};
  dots.forEach(d=>d.onclick=()=>setStep(+d.dataset.i));
  if(!window.speechSynthesis)ov.querySelector('#tVoice').style.display='none';

  /* ---------- 3D scene ---------- */
  let bot=null,enter=()=>{},resize=()=>{};
  const ok=(()=>{if(!window.THREE)return false;try{R=new THREE.WebGLRenderer({canvas:cv,alpha:true,antialias:true});return true}catch{return false}})();
  if(ok){
    R.setPixelRatio(Math.min(devicePixelRatio,2));
    const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(45,1,.1,100);
    resize=()=>{const w=cv.clientWidth||ov.clientWidth,h=cv.clientHeight||ov.clientHeight*.58;R.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();dist=Math.max(12.5,5.2/(Math.tan(Math.PI/8)*cam.aspect))};
    let dist=14;resize();addEventListener('resize',resize);
    sc.add(new THREE.AmbientLight(0xcbb8ff,.9));
    const l1=new THREE.PointLight(0xffffff,1.6,50);l1.position.set(4,8,9);const l2=new THREE.PointLight(0xff7ac8,1.3,50);l2.position.set(-7,3,6);sc.add(l1,l2);
    const mat=(c,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:c,metalness:.35,roughness:.28},o));
    function label(str,size,color,w=256,h=128){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.font=`800 ${size}px Nunito,Poppins,sans-serif`;x.textAlign='center';x.textBaseline='middle';
      x.fillStyle=color;x.shadowColor='rgba(0,0,0,.4)';x.shadowBlur=8;x.fillText(str,w/2,h/2);const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true,depthTest:false}));sp.userData.k=w/h;return sp}
    const ease=x=>1-Math.pow(1-Math.min(Math.max(x,0),1),3),clamp=(x,a=0,b=1)=>Math.min(Math.max(x,a),b);

    /* --- the coach --- */
    bot=new THREE.Group();bot.talk=false;sc.add(bot);bot.position.set(-3.4,3.6,1);bot.scale.setScalar(.85);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.85,40,28),mat(0xc4adff));head.scale.set(1.05,.88,.92);bot.add(head);
    const visor=new THREE.Mesh(new THREE.SphereGeometry(.64,32,24),mat(0x2b1a5c,{metalness:.6,roughness:.15}));visor.scale.set(1.12,.66,.5);visor.position.set(0,.02,.55);bot.add(visor);
    const eyeM=new THREE.MeshBasicMaterial({color:0x9ff3ff}),eyes=[-.27,.27].map(x=>{const e=new THREE.Mesh(new THREE.SphereGeometry(.1,16,12),eyeM);e.position.set(x,.1,.8);bot.add(e);return e});
    const mouth=new THREE.Mesh(new THREE.SphereGeometry(.08,16,12),eyeM);mouth.scale.set(1.8,.35,.5);mouth.position.set(0,-.14,.82);bot.add(mouth);
    const ant=new THREE.Mesh(new THREE.CylinderGeometry(.03,.03,.4,8),mat(0x8f6bff));ant.position.y=.95;bot.add(ant);
    const bulb=new THREE.Mesh(new THREE.SphereGeometry(.11,16,12),new THREE.MeshBasicMaterial({color:0xff7ac8}));bulb.position.y=1.2;bot.add(bulb);
    [-1,1].forEach(x=>{const ear=new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,.14,20),mat(0x8f6bff));ear.rotation.z=Math.PI/2;ear.position.set(x*.92,0,0);bot.add(ear)});
    const body=new THREE.Mesh(new THREE.SphereGeometry(.6,32,24),mat(0x8f6bff));body.scale.set(1,1.1,.85);body.position.y=-1.25;bot.add(body);
    const arm=x=>{const p=new THREE.Group();p.position.set(x*.62,-.95,0);const a=new THREE.Mesh(new THREE.CylinderGeometry(.11,.11,.62,14),mat(0xb79cff));a.position.y=-.3;const h=new THREE.Mesh(new THREE.SphereGeometry(.14,16,12),mat(0xffffff));h.position.y=-.65;p.add(a,h);bot.add(p);return p};
    const armL=arm(-1),armR=arm(1);

    /* --- scene 1: points (a crystal = lesson +10, a coin = question +2) --- */
    const g1=new THREE.Group();sc.add(g1);
    const gem=new THREE.Mesh(new THREE.OctahedronGeometry(1.1),mat(0xff7ac8,{emissive:0x7a1a58,emissiveIntensity:.5,metalness:.5,roughness:.15}));gem.position.set(-.5,2.6,0);
    const coin=new THREE.Mesh(new THREE.CylinderGeometry(.8,.8,.18,40),mat(0xffd23f,{emissive:0x6a5000,emissiveIntensity:.5,metalness:.7,roughness:.25}));coin.position.set(2.7,2.4,0);coin.rotation.x=Math.PI/2;
    const p10=label('+10',110,'#ffb3dd');p10.scale.set(2,1,1);p10.position.set(-.5,.8,0);const p2=label('+2',110,'#ffe27a');p2.scale.set(2,1,1);p2.position.set(2.7,.8,0);
    const ic1=label('🎓',100,'#fff');ic1.scale.set(.9,.9,1);ic1.position.set(-.5,4.2,0);const ic2=label('❓',100,'#fff');ic2.scale.set(.9,.9,1);ic2.position.set(2.7,4,0);
    g1.add(gem,coin,p10,p2,ic1,ic2);

    /* --- scene 2: weekly bars + trend arrow --- */
    const g2=new THREE.Group();sc.add(g2);
    const W=m.weeks,n=W.length,mxW=Math.max(...W.map(w=>w.points),1),stp=.95,bw=.66,MAXH=3.2;
    const cLow=new THREE.Color(0xff9ccf),cHigh=new THREE.Color(0x8f6bff);
    const plat=new THREE.Mesh(new THREE.CylinderGeometry(4.6,4.6,.18,64),mat(0xb79cff,{transparent:true,opacity:.5}));plat.position.y=-.1;g2.add(plat);
    const bars=W.map((w,i)=>{const geo=new THREE.BoxGeometry(bw,1,bw);geo.translate(0,.5,0);const last=i===n-1,prev=i===n-2;
      const b=new THREE.Mesh(geo,mat(cLow.clone().lerp(cHigh,w.points/mxW),{emissive:last?0x5a2fd0:prev?0x2a1a70:0,emissiveIntensity:last?.7:.4}));b.position.x=(i-(n-1)/2)*stp;b.scale.y=.001;g2.add(b);
      const v=label(String(w.points),84,'#fff');v.scale.set(1.1,.55,1);v.visible=false;g2.add(v);const d=label(w.label,64,'#e9ddff');d.scale.set(1.15,.58,1);d.position.set(b.position.x,-.45,.7);g2.add(d);
      return{b,v,h:Math.max(.12,w.points/mxW*MAXH),delay:i*.14}});
    const up=m.thisWeek>m.lastWeek,flat=m.thisWeek===m.lastWeek;
    const arrow=new THREE.Group(),aM=mat(flat?0xffd23f:up?0x6fe3a8:0xff6b9e,{emissive:flat?0x6a5000:up?0x0a6a3e:0x7a1040,emissiveIntensity:.6});
    if(flat)arrow.add(new THREE.Mesh(new THREE.BoxGeometry(.9,.22,.22),aM));else{const h=new THREE.Mesh(new THREE.ConeGeometry(.38,.6,24),aM),s=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,.7,16),aM);h.position.y=.55;s.position.y=-.05;arrow.add(h,s);if(!up)arrow.rotation.z=Math.PI}
    g2.add(arrow);const pctL=label((m.growth>0?'+':'')+m.growth+'%',104,flat?'#ffe27a':up?'#8dffc4':'#ff9cc6',320,160);pctL.scale.set(2.4,1.2,1);pctL.position.set(2.6,5.2,1);g2.add(pctL);

    /* --- scene 3: 14 day orbs (gold = active) --- */
    const g3=new THREE.Group();sc.add(g3);
    const orbs=m.daily.map((d,i)=>{const col=i%7,row=Math.floor(i/7),o=new THREE.Mesh(new THREE.SphereGeometry(.42,28,20),mat(d.n?0xffc84a:0x6b5a9e,{emissive:d.n?0xb36b00:0x000000,emissiveIntensity:d.n?.9:0,transparent:!d.n,opacity:d.n?1:.55}));
      o.position.set((col-3)*1.12+.9,3.9-row*1.35,0);o.scale.setScalar(.001);g3.add(o);return{o,on:!!d.n,i}});
    const sLab=label('🔥 '+m.streak,120,'#ffd68a',360,170);sLab.scale.set(3.2,1.5,1);sLab.position.set(.9,1.2,0);g3.add(sLab);

    /* --- scene 4: goal ring --- */
    const g4=new THREE.Group();sc.add(g4);g4.position.set(.6,2.9,0);
    g4.add(new THREE.Mesh(new THREE.TorusGeometry(1.7,.26,16,80),mat(0x5b46a8,{transparent:true,opacity:.6})));
    let ringMesh=null,ringPct=-1;const gl=label(m.goalPct+'%',120,'#fff',340,170);gl.scale.set(2.6,1.3,1);gl.position.z=.3;g4.add(gl);
    const star=new THREE.Mesh(new THREE.OctahedronGeometry(.3),mat(0xffd23f,{emissive:0x8a6000,emissiveIntensity:.8}));g4.add(star);
    function setRing(p){const q=Math.round(p*100)/100;if(q===ringPct)return;ringPct=q;if(ringMesh){g4.remove(ringMesh);ringMesh.geometry.dispose()}
      if(p<=.005){ringMesh=null;return}ringMesh=new THREE.Mesh(new THREE.TorusGeometry(1.7,.3,16,90,Math.PI*2*Math.min(p,1)),mat(0xffb86b,{emissive:0x9a4a00,emissiveIntensity:.6}));ringMesh.rotation.z=Math.PI/2;ringMesh.scale.x=-1;g4.add(ringMesh)}

    /* --- scene 5: rocket --- */
    const g5=new THREE.Group();sc.add(g5);
    const rk=new THREE.Group();const rb=new THREE.Mesh(new THREE.CylinderGeometry(.5,.62,2,28),mat(0xffffff)),rn=new THREE.Mesh(new THREE.ConeGeometry(.5,.9,28),mat(0xff7ac8));rn.position.y=1.45;
    const rw=new THREE.Mesh(new THREE.SphereGeometry(.22,16,12),mat(0x9ff3ff,{emissive:0x2a8aa0,emissiveIntensity:.6}));rw.position.set(0,.3,.5);rk.add(rb,rn,rw);
    [0,2.1,4.2].forEach(a=>{const f=new THREE.Mesh(new THREE.BoxGeometry(.08,.7,.6),mat(0x8f6bff));f.position.set(Math.sin(a)*.62,-.85,Math.cos(a)*.62);f.rotation.y=a;rk.add(f)});
    const flame=new THREE.Mesh(new THREE.ConeGeometry(.35,1,20),new THREE.MeshBasicMaterial({color:0xffb347}));flame.rotation.x=Math.PI;flame.position.y=-1.5;rk.add(flame);g5.add(rk);
    const lp=label('🎓 '+m.done+'/'+LESSONS.length,96,'#fff',420,150);lp.scale.set(3.2,1.15,1);lp.position.set(2.6,1.2,1);g5.add(lp);

    const groups={1:g1,2:g2,3:g3,4:g4,5:g5};let cur=1;
    enter=k=>{cur=k;Object.entries(groups).forEach(([i,g])=>g.visible=+i===k);bars.forEach(b=>{b.b.scale.y=.001;b.v.visible=false});orbs.forEach(o=>o.o.scale.setScalar(.001));ringPct=-1;burst()};
    Object.values(groups).forEach(g=>g.visible=false);

    /* sparkles */
    const NS=140,sp=new Float32Array(NS*3),sv=new Float32Array(NS*3),sg=new THREE.BufferGeometry();sg.setAttribute('position',new THREE.BufferAttribute(sp,3));
    sc.add(new THREE.Points(sg,new THREE.PointsMaterial({size:.12,color:0xffe9a8,transparent:true,opacity:.95,depthWrite:false})));
    function burst(){for(let i=0;i<NS;i++){sp.set([bot.position.x,bot.position.y-.4,bot.position.z],i*3);const a=Math.random()*6.283,b=Math.random()*3.14-1.57,v=1.2+Math.random()*3;sv.set([Math.cos(a)*Math.cos(b)*v,Math.sin(b)*v+1,Math.sin(a)*Math.cos(b)*v],i*3)}}

    let px=0;cv.addEventListener('pointermove',e=>{px=e.clientX/innerWidth-.5});
    const clock=new THREE.Clock();
    (function loop(){if(disposed)return;raf=requestAnimationFrame(loop);
      const dt=Math.min(clock.getDelta(),.05),T=clock.elapsedTime,t=performance.now()/1000-sceneT0;
      bot.talk=!typed||speaking;
      bot.position.y=3.6+Math.sin(T*1.8)*.12;bot.rotation.y=px*.5+.25;
      eyes.forEach(e=>e.scale.y=(T%3.4)>3.3?.1:1);mouth.scale.y=bot.talk?.35+Math.abs(Math.sin(T*14))*1.1:.35;bulb.scale.setScalar(1+Math.sin(T*5)*.25);
      armR.rotation.z=-.5-Math.sin(T*(bot.talk?7:3))*(bot.talk?.55:.25);armL.rotation.z=.35+Math.sin(T*2)*.06;
      /* scene animations */
      if(cur===1){gem.rotation.y=T*1.4;gem.position.y=2.6+Math.sin(T*2)*.15;coin.rotation.z=T*3;coin.position.y=2.4+Math.sin(T*2+1)*.15;
        const k=ease(t/.8);g1.scale.setScalar(.2+.8*k)}
      if(cur===2){bars.forEach(b=>{const k=ease((t-.4-b.delay)/.9);b.b.scale.y=Math.max(.001,b.h*k);b.v.position.set(b.b.position.x,b.b.scale.y+.4,0);b.v.visible=k>.9});
        const lb=bars[n-1];arrow.position.set(lb.b.position.x,lb.b.scale.y+1.2+Math.sin(T*3)*.12,0);arrow.rotation.y=T*1.5;pctL.position.y=5.2+Math.sin(T*1.5)*.1;g2.rotation.y=Math.sin(T*.5)*.15}
      if(cur===3){orbs.forEach(o=>{const k=ease((t-.3-o.i*.1)/.5);o.o.scale.setScalar(Math.max(.001,k)*(o.on?1+Math.sin(T*4+o.i)*.06:1));o.o.position.z=o.on?Math.sin(T*2+o.i)*.15:0});sLab.position.y=1.2+Math.sin(T*1.6)*.08}
      if(cur===4){setRing(ease((t-.3)/1.6)*m.goalPct/100);const th=Math.PI*2*Math.min(m.goalPct/100,1)*ease((t-.3)/1.6);star.position.set(Math.sin(th)*1.7,Math.cos(th)*1.7,.1);star.rotation.y=T*3;star.rotation.x=T*2;g4.rotation.y=Math.sin(T*.7)*.25}
      if(cur===5){const k=ease(t/1.6);rk.position.set(.3,1.2+k*2.2+Math.sin(T*3)*.08,0);rk.rotation.z=Math.sin(T*2)*.08;flame.scale.set(1,.8+Math.abs(Math.sin(T*18))*.7,1);lp.position.y=1.2+k*2.2}
      for(let i=0;i<NS;i++){sv[i*3+1]-=2.2*dt;sp[i*3]+=sv[i*3]*dt;sp[i*3+1]+=sv[i*3+1]*dt;sp[i*3+2]+=sv[i*3+2]*dt;if(sp[i*3+1]<-1.5){sp[i*3+1]=-1.5;sv[i*3]*=.9;sv[i*3+1]=Math.abs(sv[i*3+1])*.25;sv[i*3+2]*=.9}}
      sg.attributes.position.needsUpdate=true;
      cam.position.set(px*1.6,3.4,dist);cam.lookAt(0,2.5,0);
      /* autoplay: next scene once text is typed, the voice has finished and a short hold has passed */
      if(playing&&typed&&!speaking&&holdAt&&performance.now()-holdAt>(voice&&window.speechSynthesis?1400:2800)){if(idx<steps.length-1)setStep(idx+1);else{holdAt=0}}
      R.render(sc,cam)})();
  }
  setStep(0);
}
