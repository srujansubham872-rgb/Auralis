// Paste into Neo4j Browser (http://localhost:7474)
// See every student with everything connected to them:
MATCH (s:Student)-[r]->(x) RETURN s, r, x;
// Table of students:
MATCH (s:Student) RETURN s.name, s.contact, s.age, s.language;
// Lessons completed per student:
MATCH (s:Student)-[:COMPLETED]->(l:Lesson) RETURN s.name, collect(l.id) AS lessons;
// Students per plan:
MATCH (s:Student)-[:SUBSCRIBED_TO]->(p:Plan) RETURN p.id, p.price, count(s) AS students;
