"""Student storage. Neo4j graph database (preferred) with an in-memory fallback so the app still starts without Neo4j.

Graph model:
(:Student {contact,name,gender,age,language,created})
  -[:INTERESTED_IN]->(:Category {id})        c1..c4
  -[:COMPLETED {at}]->(:Lesson {id})
  -[:HAS_REMINDER]->(:Reminder {id,lesson,date,time,repeat,active})
  -[:SUBSCRIBED_TO {since,months}]->(:Plan {id,price})
  -[:ASKED]->(:Question {text,at})
"""
from datetime import datetime, timezone
def _now(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")

GET = """MATCH (s:Student {contact:$c})
RETURN s.name AS name, s.gender AS gender, s.age AS age, s.contact AS contact, s.language AS language,
 [(s)-[:INTERESTED_IN]->(x:Category)|x.id] AS categories,
 [(s)-[:COMPLETED]->(l:Lesson)|l.id] AS done,
 [(s)-[:HAS_REMINDER]->(r:Reminder)|r{.id,.lesson,.date,.time,.repeat,.active}] AS reminders,
 head([(s)-[:SUBSCRIBED_TO]->(p:Plan)|p.id]) AS plan"""

class Neo4jStore:
    kind = "neo4j"
    def __init__(self, uri, user, pw):
        from neo4j import GraphDatabase
        self.d = GraphDatabase.driver(uri, auth=(user, pw)); self.d.verify_connectivity()
        self.run("CREATE CONSTRAINT student_contact IF NOT EXISTS FOR (s:Student) REQUIRE s.contact IS UNIQUE")
        self.run("CREATE CONSTRAINT lesson_id IF NOT EXISTS FOR (l:Lesson) REQUIRE l.id IS UNIQUE")
    def run(self, q, **p):
        with self.d.session() as se: return [r.data() for r in se.run(q, **p)]
    def save_student(self, c, name, gender, age):
        self.run("MERGE (s:Student {contact:$c}) ON CREATE SET s.created=datetime({timezone:'UTC'}), s.language='en' SET s.name=$n, s.gender=$g, s.age=$a", c=c, n=name, g=gender, a=age)
    def get_student(self, c):
        r = self.run(GET, c=c); return r[0] if r else None
    def set_language(self, c, v): self.run("MATCH (s:Student {contact:$c}) SET s.language=$v", c=c, v=v)
    def set_plan(self, c, plan, price):
        self.run("""MATCH (s:Student {contact:$c}) OPTIONAL MATCH (s)-[o:SUBSCRIBED_TO]->() DELETE o WITH DISTINCT s
                    MERGE (p:Plan {id:$p}) SET p.price=$price CREATE (s)-[:SUBSCRIBED_TO {since:datetime({timezone:'UTC'}), months:3}]->(p)""", c=c, p=plan, price=price)
    def set_categories(self, c, cats):
        self.run("""MATCH (s:Student {contact:$c}) OPTIONAL MATCH (s)-[r:INTERESTED_IN]->() DELETE r WITH DISTINCT s
                    UNWIND $cats AS id MERGE (x:Category {id:id}) MERGE (s)-[:INTERESTED_IN]->(x)""", c=c, cats=cats)
    def complete_lesson(self, c, lesson):
        self.run("MATCH (s:Student {contact:$c}) MERGE (l:Lesson {id:$l}) MERGE (s)-[r:COMPLETED]->(l) ON CREATE SET r.at=datetime({timezone:'UTC'})", c=c, l=lesson)
    def add_reminder(self, c, r):
        self.run("MATCH (s:Student {contact:$c}) CREATE (s)-[:HAS_REMINDER]->(:Reminder {id:$id, lesson:$lesson, date:$date, time:$time, repeat:$repeat, active:$active})", c=c, **r)
    def delete_reminder(self, c, rid):
        self.run("MATCH (:Student {contact:$c})-[:HAS_REMINDER]->(r:Reminder {id:$id}) DETACH DELETE r", c=c, id=rid)
    def log_question(self, c, text):
        self.run("MATCH (s:Student {contact:$c}) CREATE (s)-[:ASKED]->(:Question {text:$t, at:datetime({timezone:'UTC'})})", c=c, t=text)
    def events(self, c):   # activity timeline used by the Growth Coach
        a = self.run("MATCH (:Student {contact:$c})-[r:COMPLETED]->() RETURN toString(r.at) AS at", c=c)
        b = self.run("MATCH (:Student {contact:$c})-[:ASKED]->(q:Question) RETURN toString(q.at) AS at", c=c)
        return [("lesson", x["at"]) for x in a] + [("question", x["at"]) for x in b]
    def all_students(self):
        return self.run("""MATCH (s:Student) RETURN s.name AS name, s.contact AS contact, s.language AS language,
                           size([(s)-[:COMPLETED]->()|1]) AS lessons, head([(s)-[:SUBSCRIBED_TO]->(p)|p.id]) AS plan ORDER BY s.created DESC""")

class MemoryStore:
    kind = "memory"
    def __init__(self): self.st = {}
    def save_student(self, c, name, gender, age):
        d = self.st.setdefault(c, dict(contact=c, language="en", categories=[], done=[], reminders=[], plan=None, questions=[], events=[]))
        d.update(name=name, gender=gender, age=age)
    def get_student(self, c):
        d = self.st.get(c); return d and {k: v for k, v in d.items() if k not in ("questions", "events")}
    def set_language(self, c, v): self.st[c]["language"] = v
    def set_plan(self, c, plan, price): self.st[c]["plan"] = plan
    def set_categories(self, c, cats): self.st[c]["categories"] = cats
    def complete_lesson(self, c, l):
        if l not in self.st[c]["done"]: self.st[c]["done"].append(l); self.st[c]["events"].append(("lesson", _now()))
    def add_reminder(self, c, r): self.st[c]["reminders"].append(r)
    def delete_reminder(self, c, rid): self.st[c]["reminders"] = [r for r in self.st[c]["reminders"] if r["id"] != rid]
    def log_question(self, c, text): self.st[c]["questions"].append(text); self.st[c]["events"].append(("question", _now()))
    def events(self, c): return list(self.st[c]["events"])
    def all_students(self):
        return [dict(name=d["name"], contact=c, language=d["language"], lessons=len(d["done"]), plan=d["plan"]) for c, d in self.st.items()]

def connect(uri, user, pw):
    try:
        s = Neo4jStore(uri, user, pw); print("Connected to Neo4j at", uri); return s
    except Exception as e:
        print(f"WARNING: Neo4j not available ({e.__class__.__name__}: {e}). Using in-memory store; data is lost on restart.")
        return MemoryStore()
