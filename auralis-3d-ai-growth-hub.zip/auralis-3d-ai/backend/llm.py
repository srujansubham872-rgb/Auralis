"""One place for every AI call in Auralis (chat, grammar, follow-ups, exam plan insights, Growth Coach).

Pick the provider with an API key (put it in backend/.env, see .env.example):
    OPENAI_API_KEY=sk-...        -> OpenAI   (model: OPENAI_MODEL, default gpt-4o-mini)
    ANTHROPIC_API_KEY=sk-ant-... -> Claude   (model: ANTHROPIC_MODEL)   [used only if no OpenAI key]
No key (or any API error) -> every caller falls back to its built-in rule-based answer, so the app never breaks.
The key stays on the server. It is never sent to the browser.
"""
import json, os, re
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).with_name(".env"))
except ImportError:      # python-dotenv is optional; plain environment variables still work
    pass

LANG_NAME = {"en": "English", "hi": "Hindi", "or": "Odia", "ur": "Urdu"}
_last_error = None


def provider() -> str:
    if os.getenv("OPENAI_API_KEY", "").strip(): return "openai"
    if os.getenv("ANTHROPIC_API_KEY", "").strip(): return "anthropic"
    return "rules"


def last_error():
    return _last_error


def complete(system: str, user: str, json_mode: bool = False, max_tokens: int = 700):
    """Return the model's text, or None when no key is set or the call fails."""
    global _last_error
    p = provider()
    if p == "rules": return None
    try:
        if p == "openai":
            from openai import OpenAI
            client = OpenAI(api_key=os.environ["OPENAI_API_KEY"].strip(), base_url=os.getenv("OPENAI_BASE_URL") or None, timeout=30)
            kw = {"response_format": {"type": "json_object"}} if json_mode else {}
            r = client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"), max_completion_tokens=max_tokens, temperature=0.6,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}], **kw)
            out = r.choices[0].message.content
        else:
            import anthropic
            r = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"].strip()).messages.create(
                model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"), max_tokens=max_tokens, system=system,
                messages=[{"role": "user", "content": user + ("\nReply with JSON only." if json_mode else "")}])
            out = r.content[0].text
        _last_error = None
        return (out or "").strip() or None
    except Exception as e:          # bad key, no credit, network down, ...
        _last_error = f"{e.__class__.__name__}: {e}"
        print("LLM call failed ->", _last_error)
        return None


def complete_json(system: str, user: str, max_tokens: int = 900):
    """Return a parsed dict, or None."""
    txt = complete(system, user, json_mode=True, max_tokens=max_tokens)
    if not txt: return None
    m = re.search(r"\{.*\}", txt, re.S)
    try:
        d = json.loads(m.group(0) if m else txt)
        return d if isinstance(d, dict) else None
    except Exception:
        return None
