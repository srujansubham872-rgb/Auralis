"""Growth Coach agent: turns a student's activity history (from Neo4j) into weekly growth numbers + a short coaching message.
Growth points: 10 per completed lesson, 2 per chatbot question. Set OPENAI_API_KEY (or ANTHROPIC_API_KEY) in backend/.env to let the AI write the message;
without a key (or if the call fails) a built-in rule-based message in the student's language is used."""
import json, os
from llm import complete, LANG_NAME
from datetime import datetime, timedelta, timezone

PTS = {"lesson": 10, "question": 2}
LESSON_IDS = ["paint", "boat", "stretch", "sing", "words"]
TXT = {
 "en": {"head": "{name}, your average weekly growth is {g}% — {p} points and {l} lessons a week.", "up": "This week is better than last week ({c} points). Great work!", "down": "This week is a little lower ({c} points). A short lesson today will fix it.", "flat": "This week matches last week ({c} points). Keep going!"},
 "hi": {"head": "{name}, आपकी औसत साप्ताहिक प्रगति {g}% है — हफ़्ते में {p} अंक और {l} पाठ।", "up": "यह हफ़्ता पिछले हफ़्ते से बेहतर है ({c} अंक)। शाबाश!", "down": "यह हफ़्ता थोड़ा कम है ({c} अंक)। आज एक छोटा पाठ इसे ठीक कर देगा।", "flat": "यह हफ़्ता पिछले हफ़्ते जैसा है ({c} अंक)। लगे रहिए!"},
 "or": {"head": "{name}, ଆପଣଙ୍କ ହାରାହାରି ସାପ୍ତାହିକ ପ୍ରଗତି {g}% — ସପ୍ତାହକୁ {p} ପଏଣ୍ଟ ଓ {l} ପାଠ।", "up": "ଏହି ସପ୍ତାହ ଗତ ସପ୍ତାହଠାରୁ ଭଲ ({c} ପଏଣ୍ଟ)। ବହୁତ ବଢ଼ିଆ!", "down": "ଏହି ସପ୍ତାହ ଟିକେ କମ୍ ({c} ପଏଣ୍ଟ)। ଆଜି ଗୋଟିଏ ଛୋଟ ପାଠ ଏହାକୁ ଠିକ୍ କରିଦେବ।", "flat": "ଏହି ସପ୍ତାହ ଗତ ସପ୍ତାହ ପରି ({c} ପଏଣ୍ଟ)। ଚାଲିଥାଆନ୍ତୁ!"},
 "ur": {"head": "{name}، آپ کی اوسط ہفتہ وار ترقی {g}% ہے — ہفتے میں {p} پوائنٹس اور {l} اسباق۔", "up": "یہ ہفتہ پچھلے ہفتے سے بہتر ہے ({c} پوائنٹس)۔ شاباش!", "down": "یہ ہفتہ کچھ کم ہے ({c} پوائنٹس)۔ آج ایک مختصر سبق اسے ٹھیک کر دے گا۔", "flat": "یہ ہفتہ پچھلے ہفتے جیسا ہے ({c} پوائنٹس)۔ لگے رہیں!"},
}

def _now(): return datetime.now(timezone.utc).replace(tzinfo=None)

def weekly(events):
    """events: [(kind, 'YYYY-MM-DDTHH:MM:SS...')] -> weekly buckets (Mon-Sun), last 8 weeks, empty weeks included."""
    evs = [(k, datetime.strptime(at[:19], "%Y-%m-%dT%H:%M:%S")) for k, at in events if at]
    if not evs: return []
    first = min(t for _, t in evs)
    m0 = (first - timedelta(days=first.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    n = (_now() - m0).days // 7 + 1
    weeks = [{"week": (m0 + timedelta(weeks=i)).strftime("%d %b"), "lessons": 0, "questions": 0, "points": 0} for i in range(max(n, 1))]
    for k, t in evs:
        i = (t - m0).days // 7
        if 0 <= i < len(weeks):
            weeks[i]["lessons" if k == "lesson" else "questions"] += 1; weeks[i]["points"] += PTS[k]
    return weeks[-8:]

def analyze(weeks):
    if not weeks: return None
    pts = [w["points"] for w in weeks]; n = len(pts)
    changes = [(b - a) / a * 100 for a, b in zip(pts, pts[1:]) if a > 0]     # week-over-week % change
    prev = pts[-2] if n > 1 else None
    streak = 0
    for w in reversed(weeks):
        if w["points"] > 0: streak += 1
        else: break
    return {"weeks": weeks, "avg_points": round(sum(pts) / n, 1), "avg_lessons": round(sum(w["lessons"] for w in weeks) / n, 1),
            "avg_growth_pct": round(sum(changes) / len(changes), 1) if changes else 0.0,
            "current": pts[-1], "previous": prev, "streak_weeks": streak, "best_week": max(weeks, key=lambda w: w["points"])["week"],
            "trend": "flat" if prev is None or pts[-1] == prev else ("up" if pts[-1] > prev else "down")}

def narrate(name, s, lang):
    lang = lang if lang in TXT else "en"; t = TXT[lang]
    base = t["head"].format(name=name, g=f"{s['avg_growth_pct']:+.1f}", p=s["avg_points"], l=s["avg_lessons"]) + " " + t[s["trend"]].format(c=s["current"])
    facts = json.dumps({k: v for k, v in s.items() if k != "weeks"})
    txt = complete("You are Auralis Growth Coach, a warm, encouraging tutor. Use simple words.",
                   f"Write 3 short friendly sentences in {LANG_NAME[lang]} for the student {name}: their average weekly growth % and weekly points, "
                   f"how this week compares with last week, and one encouragement. Facts: {facts}", max_tokens=300)
    if txt: return txt, "ai"
    return base, "rules"

def demo_events():
    """Six sample weeks so a new student can preview the report."""
    out = []
    for w, (les, qs) in enumerate([(1, 2), (1, 3), (2, 3), (2, 5), (3, 6), (4, 8)]):
        t = (_now() - timedelta(weeks=5 - w)).strftime("%Y-%m-%dT%H:%M:%S")
        out += [("lesson", t)] * les + [("question", t)] * qs
    return out
