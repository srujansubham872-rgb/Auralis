"""Auralis API (FastAPI + Neo4j). Run: uvicorn main:app --reload   -> http://localhost:8000 (also serves the frontend)
Env (defaults match docker-compose.yml): NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD, ADMIN_KEY"""
import os, re, secrets
from pathlib import Path
from typing import List, Optional
from fastapi import FastAPI, Header, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import llm                      # loads backend/.env (OPENAI_API_KEY ...) - keep this before anything reads os.getenv
import tutor
import voice                    # text-to-speech in en / hi / or / ur (see voice.py)
from db import connect
from growth import weekly, analyze, narrate, demo_events, LESSON_IDS

store = connect(os.getenv("NEO4J_URI", "bolt://localhost:7687"), os.getenv("NEO4J_USER", "neo4j"), os.getenv("NEO4J_PASSWORD", "auralis123"))
ADMIN_KEY = os.getenv("ADMIN_KEY", "admin123")
PRICES = {"basic": 199, "medium": 299, "premium": 399}
LANGS = {"en", "hi", "or", "ur"}
OTPS, TOKENS = {}, {}          # sessions live in memory (restart = log in again); student data lives in the database

app = FastAPI(title="Auralis API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class Signup(BaseModel): name: str; gender: str = ""; age: int; contact: str
class Verify(BaseModel): contact: str; otp: str
class Profile(BaseModel): language: Optional[str] = None; categories: Optional[List[str]] = None; plan: Optional[str] = None
class Done(BaseModel): lesson_id: str
class Reminder(BaseModel): id: str; a: str; d: str = ""; t: str = "18:00"; rep: str = "daily"; on: bool = True
class Msg(BaseModel): text: str; lang: str = "en"
class Lesson(BaseModel): id: str; title: str = ""; steps: List[str] = []
class FollowReq(BaseModel): lesson: Lesson; lang: str = "en"
class ExamReq(BaseModel): lessons: List[Lesson]; days: int = 7; lang: str = "en"

def user_of(authorization: str = "") -> Optional[str]:
    return TOKENS.get(authorization.removeprefix("Bearer ").strip())
def need_user(authorization: str) -> str:
    c = user_of(authorization)
    if not c: raise HTTPException(401, "Missing or invalid token")
    return c

@app.get("/api/health")
def health(): return {"ok": True, "db": store.kind, "llm": llm.provider(), "llm_error": llm.last_error()}   # llm: openai | anthropic | rules

@app.post("/api/auth/signup")
def signup(b: Signup):
    store.save_student(b.contact, b.name, b.gender, b.age)    # same contact again = same student, data kept
    OTPS[b.contact] = "1234"                                   # demo OTP; use an SMS/email provider in production
    return {"sent": True}

@app.post("/api/auth/verify")
def verify(b: Verify):
    if OTPS.get(b.contact) != b.otp: raise HTTPException(400, "Wrong OTP")
    token = secrets.token_urlsafe(24); TOKENS[token] = b.contact
    return {"token": token, "student": store.get_student(b.contact)}

@app.get("/api/me")
def me(authorization: str = Header(default="")): return store.get_student(need_user(authorization))

@app.put("/api/me")
def update_me(p: Profile, authorization: str = Header(default="")):
    c = need_user(authorization)
    if p.language in LANGS: store.set_language(c, p.language)
    if p.categories is not None: store.set_categories(c, [x for x in p.categories if re.fullmatch(r"c[1-4]", x)])
    if p.plan in PRICES: store.set_plan(c, p.plan, PRICES[p.plan])
    return store.get_student(c)

@app.post("/api/progress")
def progress(b: Done, authorization: str = Header(default="")):
    c = need_user(authorization); store.complete_lesson(c, b.lesson_id); return {"done": store.get_student(c)["done"]}

@app.post("/api/reminders")
def add_reminder(r: Reminder, authorization: str = Header(default="")):
    store.add_reminder(need_user(authorization), dict(id=r.id, lesson=r.a, date=r.d, time=r.t, repeat=r.rep, active=r.on)); return {"ok": True}

@app.delete("/api/reminders/{rid}")
def delete_reminder(rid: str, authorization: str = Header(default="")):
    store.delete_reminder(need_user(authorization), rid); return {"ok": True}

@app.get("/api/me/growth")          # Growth Coach: average weekly growth + coaching message (?lang=hi&demo=1)
def growth_report(lang: str = "en", demo: int = 0, authorization: str = Header(default="")):
    c = need_user(authorization); st = store.get_student(c)
    stats = analyze(weekly(demo_events() if demo else store.events(c)))
    if not stats: return {"stats": None, "message": ""}
    stats["next_lesson"] = next((l for l in LESSON_IDS if l not in st["done"]), None)
    msg, source = narrate(st["name"], stats, lang)
    return {"stats": stats, "message": msg, "agent": source, "demo": bool(demo)}

@app.get("/api/admin/students")     # teacher/admin view of every student; send header  x-admin-key
def students(x_admin_key: str = Header(default="")):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Bad admin key")
    return store.all_students()

@app.post("/api/chat")
def chat(m: Msg, authorization: str = Header(default="")):
    c = user_of(authorization)
    if c: store.log_question(c, m.text)
    return tutor.answer(m.text, m.lang)

@app.post("/api/grammar")
def grammar(m: Msg): return tutor.grammar(m.text, m.lang)

@app.post("/api/followups")         # auto follow-up questions after a finished lesson
def followups(r: FollowReq): return tutor.followups(r.lesson.title or r.lesson.id, r.lesson.steps, r.lang)

@app.post("/api/exam/insights")     # AI message + practice questions + tips for the auto-built exam plan
def exam_insights(r: ExamReq): return tutor.exam_insights([l.model_dump() for l in r.lessons], max(1, min(r.days, 60)), r.lang)

class TTSReq(BaseModel): text: str; lang: str = "en"

@app.post("/api/tts")                # spoken audio (mp3) for any text in en / hi / or / ur; 503 = no voice provider set up
def tts(req: TTSReq):
    if req.lang not in LANGS: raise HTTPException(400, "lang must be en, hi, or or ur")
    audio, how = voice.synth(req.text, req.lang)
    if not audio: raise HTTPException(503, f"No voice for {req.lang} ({how})")
    return Response(audio, media_type="audio/mpeg", headers={"X-TTS": how, "Cache-Control": "public, max-age=86400"})

@app.get("/api/tts/status")
def tts_status(): return voice.status()

app.mount("/", StaticFiles(directory=str(Path(__file__).resolve().parent.parent / "frontend"), html=True), name="web")
