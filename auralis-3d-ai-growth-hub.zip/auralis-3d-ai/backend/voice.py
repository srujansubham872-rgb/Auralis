"""Text-to-speech for Auralis in 4 languages: en (English), hi (Hindi), or (Odia), ur (Urdu).

Why a server voice? Many phones have NO Odia (and some no Urdu) voice, so the browser cannot speak it.
Providers are tried in this order (first one that works wins; every result is cached on disk in tts_cache/):
  1. azure  - Microsoft Azure Speech (all 4 languages, best quality).  .env: AZURE_SPEECH_KEY, AZURE_SPEECH_REGION (e.g. centralindia)
  2. edge   - `pip install edge-tts` (free, no key; en/hi/ur work, Odia only if the service offers it)
  3. gtts   - `pip install gTTS` (free; en/hi/ur, NO Odia)
Change the order with TTS_PROVIDERS=azure,edge,gtts in .env. If nothing can speak a language the API answers 503 and the
app falls back to the phone's own voice (and tells the student if the phone has none)."""
import asyncio, hashlib, io, os
from pathlib import Path
from xml.sax.saxutils import escape

CACHE = Path(__file__).resolve().parent / "tts_cache"
CACHE.mkdir(exist_ok=True)
LOCALE = {"en": "en-IN", "hi": "hi-IN", "or": "or-IN", "ur": "ur-PK"}
VOICE = {"en": "en-IN-NeerjaNeural", "hi": "hi-IN-SwaraNeural", "or": "or-IN-SubhasiniNeural", "ur": "ur-PK-UzmaNeural"}
GTTS = {"en": "en", "hi": "hi", "ur": "ur"}            # gTTS has no Odia
ORDER = [p.strip() for p in os.getenv("TTS_PROVIDERS", "azure,edge,gtts").split(",") if p.strip()]


def _azure(text, lang):
    key, region = os.getenv("AZURE_SPEECH_KEY", ""), os.getenv("AZURE_SPEECH_REGION", "")
    if not (key and region):
        return None
    import requests
    ssml = (f"<speak version='1.0' xml:lang='{LOCALE[lang]}'><voice name='{VOICE[lang]}'>"
            f"<prosody rate='-5%'>{escape(text)}</prosody></voice></speak>")
    r = requests.post(f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1",
                      headers={"Ocp-Apim-Subscription-Key": key, "Content-Type": "application/ssml+xml",
                               "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3", "User-Agent": "auralis"},
                      data=ssml.encode("utf-8"), timeout=20)
    return r.content if r.ok and r.content else None


def _edge(text, lang):
    import edge_tts

    async def run():
        out = b""
        async for c in edge_tts.Communicate(text, VOICE[lang], rate="-5%").stream():
            if c["type"] == "audio":
                out += c["data"]
        return out
    return asyncio.run(run()) or None


def _gtts(text, lang):
    if lang not in GTTS:
        return None
    from gtts import gTTS
    buf = io.BytesIO()
    gTTS(text, lang=GTTS[lang]).write_to_fp(buf)
    return buf.getvalue() or None


def or2hi(s: str) -> str:
    """Odia script -> Devanagari (same Brahmic layout, offset 0x200) so a Hindi voice can read it (approximate Odia sound)."""
    over = {0x2F: 0x91C, 0x5F: 0x92F, 0x33: 0x932, 0x71: 0x935}     # ଯ->ज (Odia says "ja"), ୟ->य, ଳ->ल, ୱ->व
    return "".join(chr(over.get(ord(c) - 0xB00, ord(c) - 0xB00 + 0x900)) if 0xB01 <= ord(c) <= 0xB77 else c for c in s)


PROV = {"azure": _azure, "edge": _edge, "gtts": _gtts}


def synth(text: str, lang: str):
    """Returns (mp3_bytes, provider) or (None, error_text). Never raises."""
    text = " ".join(text.split())[:600]
    if not text or lang not in LOCALE:
        return None, "bad request"
    f = CACHE / (hashlib.sha1(f"{lang}|{text}".encode("utf-8")).hexdigest() + ".mp3")
    if f.exists():
        return f.read_bytes(), "cache"
    errs = []
    for name in ORDER:
        fn = PROV.get(name)
        if not fn:
            continue
        try:
            audio = fn(text, lang)
            if audio:
                f.write_bytes(audio)
                return audio, name
            errs.append(f"{name}: no audio")
        except Exception as e:                      # missing package, no key, offline, language not offered ...
            errs.append(f"{name}: {type(e).__name__}")
    if lang == "or":                                  # no real Odia voice available: read it with a Hindi voice (approximate)
        audio, how = synth(or2hi(text), "hi")
        if audio:
            f.write_bytes(audio)
            return audio, "hi-approx"
        errs.append("hi-approx: " + how)
    return None, "; ".join(errs) or "no provider"


def status():
    """Which providers are set up (for GET /api/tts/status)."""
    def has(m):
        try:
            __import__(m)
            return True
        except Exception:
            return False
    az = bool(os.getenv("AZURE_SPEECH_KEY") and os.getenv("AZURE_SPEECH_REGION"))
    return {"order": ORDER, "azure_key": az, "edge_tts": has("edge_tts"), "gtts": has("gtts"),
            "odia_real_voice": az or has("edge_tts"), "odia_hindi_approx": has("edge_tts") or has("gtts"), "cached_clips": len(list(CACHE.glob("*.mp3")))}
