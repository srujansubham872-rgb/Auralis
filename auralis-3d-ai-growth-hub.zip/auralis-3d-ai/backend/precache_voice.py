"""Pre-generate (and cache) the spoken audio for EVERY lesson text in all 4 languages, so lessons play instantly.
Run once after configuring a voice provider:   python precache_voice.py        (needs Node.js to read frontend/js/data.js)"""
import json, re, subprocess
from pathlib import Path
import voice

JS = Path(__file__).resolve().parent.parent / "frontend" / "js" / "data.js"
node = """const fs=require('fs');eval(fs.readFileSync(process.argv[1],'utf8').replace(/const /g,'var '));
console.log(JSON.stringify({L:LESSONS,T:T}))"""
D = json.loads(subprocess.check_output(["node", "-e", node, str(JS)], text=True, encoding="utf-8"))
IDX = {"en": 0, "hi": 1, "or": 2, "ur": 3}
END = re.compile(r"[.!?\u0964\u06d4\u061f]$")
sent = lambda x: x.strip() if END.search(x.strip()) else x.strip() + "."
def chunks(text, n=200):                                  # same rule as chunkText() in frontend/js/app.js
    out, cur = [], ""
    for p in re.findall(r"[^.!?\u0964\u06d4\u061f]+[.!?\u0964\u06d4\u061f]*\s*", text) or [text]:
        if cur and len(cur) + len(p) > n: out.append(cur.strip()); cur = ""
        cur += p
    if cur.strip(): out.append(cur.strip())
    return out
def tt(lang, k): return D["T"].get(lang, {}).get(k) or D["T"]["en"][k]

ok = bad = 0
for lang, i in IDX.items():
    for L in D["L"]:
        n = len(L["steps"]); texts = [sent(tt(lang, "complete"))]
        if L.get("mats"):
            texts.append(sent(L["title"][i]) + " " + sent(tt(lang, "mats") + ": " + ", ".join((m[i + 1] or m[1]) for m in L["mats"])))
        for k, s in enumerate(L["steps"]):
            t = sent(tt(lang, "stepSay").replace("{n}", str(k + 1)).replace("{m}", str(n))) + " " + sent(s[i + 1] or s[1])
            if len(s) > 5 and s[5]: t += " " + sent(tt(lang, "tip") + ": " + tt(lang, "tipText"))
            texts.append(t)
        for t in texts:
            for c in chunks(t):
                audio, how = voice.synth(c, lang)
                ok += bool(audio); bad += not audio
                if not audio: print("  no voice:", lang, how); break
    print(lang, "done")
print(f"clips ready: {ok}, failed: {bad}")
