"""Auralis tutor agent: chat answers, grammar help, auto follow-up questions and exam-plan insights.
Every function asks the LLM (see llm.py) and falls back to a simple rule-based result when no key is set / the call fails."""
import re
from llm import complete_json, LANG_NAME, provider

SYSTEM = ("You are Auralis, a warm, patient tutor for beginners (many are children or first-time learners). "
          "Use very simple words and short sentences. Always write in the requested language. Output valid JSON only.")


def _strs(v, n, maxlen=160):
    return [str(x).strip()[:maxlen] for x in (v if isinstance(v, list) else []) if str(x).strip()][:n]


# ---------- chat ----------
def answer(q: str, lang: str) -> dict:
    d = complete_json(SYSTEM, (
        f'Language: {LANG_NAME.get(lang, "English")}.\nStudent question: "{q[:500]}"\n'
        'Teach it step by step. Return JSON: {"icon": "<one emoji>", "steps": ["3 to 5 short steps"], '
        '"summary": "one sentence: what the student learned", "followups": ["3 short follow-up questions the student may ask next"]}'))
    if d:
        steps, fu, sm = _strs(d.get("steps"), 6, 300), _strs(d.get("followups"), 4), str(d.get("summary", "")).strip()
        if steps and sm:
            return {"icon": str(d.get("icon") or "💡")[:4], "steps": steps, "summary": sm[:300], "followups": fu or [f"Can you give another example of {q}?"], "source": provider()}
    return {"icon": "💡",
            "steps": [f'Understand what "{q}" means in one sentence.', "Look at one simple example.", "Try it yourself once.", "Explain it back in your own words."],
            "followups": [f"Can you give another example of {q}?", "What is a common mistake here?", "How can I practise this offline?"],
            "summary": f"You learned the core idea of {q} and practised it.", "source": "rules"}


# ---------- grammar ----------
FIXES = [(r"\bi\b", "I"), (r"\bdont\b", "don't"), (r"\bcant\b", "can't"), (r"\bim\b", "I'm"), (r"\bteh\b", "the"), (r"\s{2,}", " ")]


def grammar(text: str, lang: str) -> dict:
    d = complete_json(SYSTEM, (
        f'The student wrote in {LANG_NAME.get(lang, "English")}: "{text[:600]}"\n'
        'Fix spelling and grammar. Return JSON: {"corrected": "the fixed text", "notes": ["each change explained in one short sentence, in the same language"]}'))
    if d and str(d.get("corrected", "")).strip():
        return {"corrected": str(d["corrected"]).strip(), "notes": _strs(d.get("notes"), 6) or ["No mistakes found"], "source": provider()}
    out, notes = text.strip(), []
    for pat, rep in FIXES:
        new = re.sub(pat, rep, out)
        if new != out: notes.append(f"{pat} → {rep}"); out = new
    if out and out[0].islower(): out = out[0].upper() + out[1:]; notes.append("Capitalised first letter")
    if out and out[-1] not in ".?!": out += "."; notes.append("Added end punctuation")
    return {"corrected": out, "notes": notes or ["No mistakes found"], "source": "rules"}


# ---------- auto follow-up questions after a lesson ----------
def followups(title: str, steps: list, lang: str) -> dict:
    d = complete_json(SYSTEM, (
        f'Language: {LANG_NAME.get(lang, "English")}. The student just finished the lesson "{title[:120]}" with these steps: {steps[:8]}.\n'
        'Write 3 follow-up questions the student should think about next (one easy, one practical, one a little deeper). '
        'Return JSON: {"questions": ["...", "...", "..."]}'))
    qs = _strs(d.get("questions"), 4) if d else []
    return {"questions": qs, "source": provider() if qs else "rules"}     # empty list -> the app uses its own local questions


# ---------- exam plan insights (message + practice questions + a tip per lesson) ----------
def exam_insights(lessons: list, days: int, lang: str) -> dict:
    names = [f'{l["id"]}: {l["title"]}' for l in lessons][:12]
    d = complete_json(SYSTEM, (
        f'Language: {LANG_NAME.get(lang, "English")}. A student finished a whole course with these lessons: {names}. Their exam is in {days} days.\n'
        'Return JSON: {"message": "2 short encouraging sentences about the exam plan", '
        '"questions": [{"lesson": "<lesson id>", "q": "a practice question"}] (2 per lesson), '
        '"tips": {"<lesson id>": "one short revision tip"}}'))
    if not d: return {"message": "", "questions": [], "tips": {}, "source": "rules"}
    ids = {l["id"] for l in lessons}
    qs = [{"lesson": str(x.get("lesson")), "q": str(x.get("q", "")).strip()[:200]} for x in (d.get("questions") or []) if isinstance(x, dict) and str(x.get("lesson")) in ids and str(x.get("q", "")).strip()][:20]
    tips = {k: str(v).strip()[:200] for k, v in (d.get("tips") or {}).items() if k in ids and str(v).strip()} if isinstance(d.get("tips"), dict) else {}
    return {"message": str(d.get("message", "")).strip()[:400], "questions": qs, "tips": tips, "source": provider()}
